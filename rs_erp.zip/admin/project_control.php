<?php
// admin/project_control.php
require_once __DIR__ . '/../includes/auth_guard.php';
require_once __DIR__ . '/../config/db_connection.php';

$user = current_user();
$page_title = "CRM Project Setup Allocator";

$errors = [];
$success_msg = "";

// 1. Handle Project Initiation from Proposal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'initiate_project') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF validation failed.");
    }

    $proposal_id = sanitize($_POST['proposal_id'] ?? '');
    $supervisor_id = sanitize($_POST['supervisor_id'] ?? '');
    $project_serial = sanitize($_POST['project_id'] ?? '');
    $title = sanitize($_POST['title'] ?? '');
    $budget = floatval($_POST['budget'] ?? 0.00);
    $start_date = sanitize($_POST['start_date'] ?? '');
    $end_date = sanitize($_POST['end_date'] ?? '');
    $category = sanitize($_POST['category'] ?? 'Development');
    $description = sanitize($_POST['description'] ?? '');

    if (empty($proposal_id) || empty($supervisor_id) || empty($project_serial) || empty($title) || empty($start_date) || empty($end_date)) {
        $errors[] = "Please fill in all required fields.";
    } else {
        $conn->begin_transaction();
        try {
            // Get proposal details to extract client_id
            $stmt = $conn->prepare("SELECT client_id FROM proposals WHERE id = ?");
            $stmt->bind_param("s", $proposal_id);
            $stmt->execute();
            $client_id = $stmt->get_result()->fetch_assoc()['client_id'] ?? '';
            $stmt->close();

            if (empty($client_id)) {
                throw new Exception("Proposal details not found.");
            }

            // Insert project
            $project_id = generate_uuid();
            $stmt = $conn->prepare("INSERT INTO projects (id, project_id, title, description, client_id, supervisor_id, status, budget, start_date, end_date, progress, category) 
                                    VALUES (?, ?, ?, ?, ?, ?, 'PLANNING', ?, ?, ?, 0, ?)");
            $stmt->bind_param("sssssssdss", $project_id, $project_serial, $title, $description, $client_id, $supervisor_id, $budget, $start_date, $end_date, $category);
            $stmt->execute();
            $stmt->close();

            // Update proposal state to mark it processed (we can set to EXPIRED or leave as APPROVED but mark it linked. Let's set its response date to indicate processing, or delete it, or update proposal status. Leave as APPROVED is fine, but to prevent duplicate projects, we can add a flag, or check if project exists for proposal title).
            // Let's create a notification for the client
            $stmt = $conn->prepare("SELECT user_id FROM clients WHERE id = ?");
            $stmt->bind_param("s", $client_id);
            $stmt->execute();
            $client_user_id = $stmt->get_result()->fetch_assoc()['user_id'] ?? '';
            $stmt->close();

            if ($client_user_id) {
                send_notification($client_user_id, "Project Initiated", "Your project '$title' has been officially scheduled and kicked off.", "CRM", "HIGH", "/client/projects.php");
            }

            $conn->commit();
            log_activity("Initiated project from proposal", ["project_title" => $title]);
            $success_msg = "Project Workspace has been successfully initialized!";
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = "Initialization failed: " . $e->getMessage();
        }
    }
}

// 2. Handle Team Member Assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'assign_team') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF validation failed.");
    }

    $project_id = sanitize($_POST['project_id'] ?? '');
    $staff_id = sanitize($_POST['staff_id'] ?? '');
    $role = sanitize($_POST['role'] ?? 'Developer');

    if (empty($project_id) || empty($staff_id) || empty($role)) {
        $errors[] = "Member role is required.";
    } else {
        try {
            $member_id = generate_uuid();
            $stmt = $conn->prepare("INSERT INTO project_team_members (id, project_id, staff_id, role) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE role = VALUES(role)");
            $stmt->bind_param("ssss", $member_id, $project_id, $staff_id, $role);
            $stmt->execute();
            $stmt->close();

            log_activity("Assigned staff to project team", ["project_id" => $project_id, "staff_id" => $staff_id]);
            $success_msg = "Team member role assigned successfully!";
        } catch (Exception $e) {
            $errors[] = "Assignment failed: " . $e->getMessage();
        }
    }
}

// Fetch staff dropdown
$staff_members = [];
try {
    $res = $conn->query("SELECT s.id, u.first_name, u.last_name FROM staff s JOIN users u ON s.user_id = u.id WHERE s.status = 'ACTIVE'");
    while ($row = $res->fetch_assoc()) {
        $staff_members[] = $row;
    }
} catch (Exception $e) {
    // Ignore
}

// Fetch approved proposals
$approved_proposals = [];
try {
    $res = $conn->query("SELECT p.*, cl.company_name FROM proposals p JOIN clients cl ON p.client_id = cl.id WHERE p.status = 'APPROVED' ORDER BY p.updated_at DESC");
    while ($row = $res->fetch_assoc()) {
        $approved_proposals[] = $row;
    }
} catch (Exception $e) {
    // Ignore
}

// Fetch active projects lists
$projects = [];
try {
    $res = $conn->query("SELECT p.*, cl.company_name, u.first_name as supervisor_first, u.last_name as supervisor_last 
                         FROM projects p 
                         JOIN clients cl ON p.client_id = cl.id 
                         LEFT JOIN staff s ON p.supervisor_id = s.id 
                         LEFT JOIN users u ON s.user_id = u.id 
                         ORDER BY p.created_at DESC");
    while ($row = $res->fetch_assoc()) {
        $projects[] = $row;
    }
} catch (Exception $e) {
    // Ignore
}

// Active project configuration select
$active_proj_id = sanitize($_GET['project_id'] ?? '');
$active_proj = null;
$team = [];

if (!empty($active_proj_id)) {
    foreach ($projects as $pr) {
        if ($pr['id'] === $active_proj_id) {
            $active_proj = $pr;
            break;
        }
    }

    if ($active_proj) {
        try {
            $stmt = $conn->prepare("SELECT ptm.*, u.first_name, u.last_name, s.department 
                                    FROM project_team_members ptm 
                                    JOIN staff s ON ptm.staff_id = s.id 
                                    JOIN users u ON s.user_id = u.id 
                                    WHERE ptm.project_id = ?");
            $stmt->bind_param("s", $active_proj_id);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                $team[] = $row;
            }
            $stmt->close();
        } catch (Exception $e) {
            // Ignore
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>

<!-- Alerts -->
<?php if (!empty($errors)): ?>
    <div
        class="mb-6 p-4 bg-red-500/10 border border-red-500/30 text-red-600  rounded-xl text-sm font-medium">
        <?php foreach ($errors as $err): ?>
            <p><?php echo $err; ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (!empty($success_msg)): ?>
    <div
        class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600  rounded-xl text-sm font-medium">
        <?php echo $success_msg; ?>
    </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <!-- Left Workspace: Proposal list & Project initiator -->
    <div class="space-y-6">

        <!-- Approved proposals awaiting kickoff -->
        <div
            class="bg-white  border border-slate-200  rounded-2xl p-6 shadow-sm">
            <h4
                class="text-sm font-bold text-slate-900  mb-4 flex items-center space-x-2 border-b border-slate-150  pb-3">
                <i data-lucide="inbox" class="w-4 h-4 text-emerald-500"></i>
                <span>Approved Contracts Kickoff Queue</span>
            </h4>

            <?php if (empty($approved_proposals)): ?>
                <p class="text-xs text-slate-400 text-center py-4">No approved contracts awaiting execution.</p>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($approved_proposals as $ap): ?>
                        <div
                            class="p-3.5 bg-slate-50  border border-slate-200/50  rounded-xl space-y-3">
                            <div>
                                <h5 class="text-xs font-bold text-slate-900 ">
                                    <?php echo sanitize($ap['title']); ?></h5>
                                <div class="flex justify-between items-center text-[9px] text-slate-400 mt-1">
                                    <span>Client: <?php echo sanitize($ap['company_name']); ?></span>
                                    <span>Budget: <?php echo format_currency($ap['amount']); ?></span>
                                </div>
                            </div>

                            <!-- Trigger form toggle -->
                            <button
                                class="w-full py-1.5 bg-emerald-650 hover:bg-emerald-555 text-white font-bold rounded-lg text-[10px] transition-all flex items-center justify-center space-x-1"
                                onclick="toggleForm('kickoff-form-<?php echo $ap['id']; ?>')">
                                <i data-lucide="play" class="w-3 h-3"></i>
                                <span>Kicked Off Project</span>
                            </button>

                            <!-- Project Initiation Form -->
                            <form id="kickoff-form-<?php echo $ap['id']; ?>" action="project_control.php" method="POST"
                                class="hidden mt-3 pt-3 border-t border-slate-150  space-y-3">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="action" value="initiate_project">
                                <input type="hidden" name="proposal_id" value="<?php echo $ap['id']; ?>">
                                <input type="hidden" name="title" value="<?php echo sanitize($ap['title']); ?>">
                                <input type="hidden" name="budget" value="<?php echo $ap['amount']; ?>">
                                <input type="hidden" name="category" value="<?php echo sanitize($ap['category']); ?>">

                                <div>
                                    <label class="block text-[9px] font-bold text-slate-400 uppercase mb-1">Custom Project
                                        Serial ID</label>
                                    <input type="text" name="project_id" required placeholder="PRJ-8821"
                                        value="PRJ-<?php echo mt_rand(1000, 9999); ?>"
                                        class="w-full px-3 py-1.5 bg-white  border border-slate-250  rounded-lg text-xs outline-none">
                                </div>

                                <div>
                                    <label class="block text-[9px] font-bold text-slate-400 uppercase mb-1">Assigned Supervisor
                                        Host</label>
                                    <select name="supervisor_id" required
                                        class="w-full px-3 py-1.5 bg-white  border border-slate-250  rounded-lg text-xs outline-none">
                                        <option value="">Choose Supervisor...</option>
                                        <?php foreach ($staff_members as $sm): ?>
                                            <option value="<?php echo $sm['id']; ?>">
                                                <?php echo sanitize($sm['first_name'] . ' ' . $sm['last_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="grid grid-cols-2 gap-2">
                                    <div>
                                        <label class="block text-[9px] font-bold text-slate-400 uppercase mb-1">Start
                                            Date</label>
                                        <input type="date" name="start_date" required value="<?php echo date('Y-m-d'); ?>"
                                            class="w-full px-3 py-1.5 bg-white  border border-slate-250  rounded-lg text-xs outline-none">
                                    </div>
                                    <div>
                                        <label class="block text-[9px] font-bold text-slate-400 uppercase mb-1">End Date</label>
                                        <input type="date" name="end_date" required
                                            value="<?php echo date('Y-m-d', strtotime('+3 months')); ?>"
                                            class="w-full px-3 py-1.5 bg-white  border border-slate-250  rounded-lg text-xs outline-none">
                                    </div>
                                </div>

                                <div>
                                    <label class="block text-[9px] font-bold text-slate-400 uppercase mb-1">Scope
                                        details</label>
                                    <textarea name="description" placeholder="Write final engineering task scopes..." rows="2"
                                        class="w-full px-3 py-2 bg-white  border border-slate-250  rounded-lg text-xs outline-none"><?php echo sanitize($ap['description']); ?></textarea>
                                </div>

                                <div class="flex justify-end space-x-2 pt-1">
                                    <button type="button" class="px-3 py-1 bg-slate-105 rounded text-[9px] font-bold"
                                        onclick="toggleForm('kickoff-form-<?php echo $ap['id']; ?>')">Cancel</button>
                                    <button type="submit"
                                        class="px-3 py-1 bg-emerald-600 text-white rounded text-[9px] font-bold shadow-sm">Save
                                        Kickoff</button>
                                </div>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- Right Panel: Active projects roster list & Allocator details (Col span 2) -->
    <div class="lg:col-span-2 space-y-6">

        <!-- Active Projects List -->
        <div
            class="bg-white  border border-slate-200  rounded-2xl p-6 shadow-sm">
            <h4
                class="text-sm font-bold text-slate-900  mb-6 flex items-center space-x-2 border-b border-slate-100  pb-3">
                <i data-lucide="briefcase" class="w-4 h-4 text-blue-500"></i>
                <span>Active CRM Project Workspaces</span>
            </h4>

            <?php if (empty($projects)): ?>
                <p class="text-xs text-slate-400 text-center py-4">No projects registered.</p>
            <?php else: ?>
                <div class="space-y-3.5">
                    <?php foreach ($projects as $pr): ?>
                        <div
                            class="p-4 bg-slate-50  border border-slate-150  rounded-xl flex items-center justify-between <?php echo $pr['id'] === $active_proj_id ? 'ring-2 ring-indigo-500' : ''; ?>">
                            <div>
                                <span
                                    class="text-[9px] bg-slate-100  px-2 py-0.5 rounded font-mono text-slate-450 uppercase font-semibold"><?php echo sanitize($pr['project_id']); ?></span>
                                <h5 class="text-xs font-bold text-slate-905  mt-1.5">
                                    <?php echo sanitize($pr['title']); ?></h5>
                                <p class="text-[9px] text-slate-400 mt-1">Client: <?php echo sanitize($pr['company_name']); ?>
                                    &bull; Supervisor:
                                    <?php echo sanitize($pr['supervisor_first'] . ' ' . $pr['supervisor_last']); ?> &bull;
                                    Status: <span class="uppercase"><?php echo sanitize($pr['status']); ?></span></p>
                            </div>

                            <a href="project_control.php?project_id=<?php echo $pr['id']; ?>"
                                class="px-3.5 py-1.5 bg-indigo-650 hover:bg-indigo-555 text-white rounded font-bold text-[10px] transition-all">
                                Manage Team
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Team allocator workflow panel -->
        <?php if ($active_proj): ?>
            <div
                class="bg-white  border border-slate-200  rounded-2xl p-6 shadow-sm space-y-6">

                <div class="flex justify-between items-center border-b border-slate-100  pb-3">
                    <div>
                        <span class="text-[9px] uppercase tracking-wider text-slate-400 font-bold block">Roster
                            Allocator</span>
                        <h4 class="text-sm font-bold text-slate-950  mt-1">
                            <?php echo sanitize($active_proj['title']); ?> Team</h4>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                    <!-- Team members list -->
                    <div class="space-y-3">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Assigned Staff
                            members</span>

                        <?php if (empty($team)): ?>
                            <p
                                class="text-xs text-slate-400 text-center py-4 border border-dashed border-slate-200  rounded-xl">
                                No engineering team allocated yet.</p>
                        <?php else: ?>
                            <div class="space-y-2">
                                <?php foreach ($team as $tm): ?>
                                    <div class="p-3 bg-slate-50  rounded-xl flex items-center justify-between">
                                        <div>
                                            <h5 class="text-xs font-bold text-slate-900 ">
                                                <?php echo sanitize($tm['first_name'] . ' ' . $tm['last_name']); ?></h5>
                                            <p class="text-[9px] text-slate-400 mt-0.5"><?php echo sanitize($tm['role']); ?> &bull;
                                                <?php echo sanitize($tm['department']); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Member allocation form -->
                    <div
                        class="bg-slate-50  border border-slate-150  p-4 rounded-xl space-y-4">
                        <span
                            class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block border-b border-slate-100  pb-2">Allocate
                            Team Member</span>

                        <form action="project_control.php?project_id=<?php echo $active_proj_id; ?>" method="POST"
                            class="space-y-3">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="action" value="assign_team">
                            <input type="hidden" name="project_id" value="<?php echo $active_proj_id; ?>">

                            <div>
                                <label for="team-staff"
                                    class="block text-[9px] font-bold text-slate-400 uppercase mb-1">Choose Engineer</label>
                                <select name="staff_id" id="team-staff" required
                                    class="w-full px-3 py-1.5 bg-white  border border-slate-250  rounded-lg text-xs outline-none">
                                    <option value="">Choose Engineer...</option>
                                    <?php foreach ($staff_members as $sm): ?>
                                        <option value="<?php echo $sm['id']; ?>">
                                            <?php echo sanitize($sm['first_name'] . ' ' . $sm['last_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div>
                                <label for="team-role"
                                    class="block text-[9px] font-bold text-slate-400 uppercase mb-1">Project Role
                                    Title</label>
                                <input type="text" name="role" id="team-role" required
                                    placeholder="Lead Architect, Developer, Quality check"
                                    class="w-full px-3 py-1.5 bg-white  border border-slate-250  rounded-lg text-xs outline-none">
                            </div>

                            <button type="submit"
                                class="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition-all shadow-sm">
                                Allocate Member
                            </button>
                        </form>
                    </div>

                </div>

            </div>
        <?php endif; ?>

    </div>

</div>

<script>
    function toggleForm(formId) {
        const form = document.getElementById(formId);
        form.classList.toggle('hidden');
    }
</script>

<?php
include __DIR__ . '/../includes/footer.php';
?>