<?php
// login.php
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/config/db_connection.php';

// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Redirect if already logged in
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
    switch ($user['role']) {
        case 'ADMIN': case 'MANAGER': header("Location: " . BASE_URL . "/admin/index.php"); break;
        case 'STAFF': header("Location: " . BASE_URL . "/staff/index.php"); break;
        case 'STUDENT': header("Location: " . BASE_URL . "/student/index.php"); break;
        case 'CLIENT': header("Location: " . BASE_URL . "/client/index.php"); break;
    }
    exit();
}

$errors = [];
$success_msg = "";

$awaiting_otp = $_SESSION['auth_otp_pending'] ?? false;
$otp_email = $_SESSION['auth_otp']['email'] ?? '';
$otp_action = $_SESSION['auth_otp']['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF Token validation failed.");
    }
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'login_submit') {
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        // Validate login fields
        $login_rules = [
            'required' => ['email', 'password'],
            'email' => [['email' => ['message' => 'Invalid email format']]],
            'minLength' => [['password' => ['min' => 6]]]
        ];
        
        $validation = validate(['email' => $email, 'password' => $password], $login_rules);
        
        if (!$validation['success']) {
            $errors = array_merge($errors, $validation['errors']);
        } else {
            $email = $validation['validated']['email'];
            $password = $validation['validated']['password'];
            try {
                $stmt = $conn->prepare("SELECT * FROM users_student WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $res = $stmt->get_result();
                $user = $res->fetch_assoc();
                $stmt->close();
                
                if ($user) {
                    if ($user['status'] !== 'ACTIVE') {
                        $errors[] = "Your account status is: " . $user['status'] . ". Access denied.";
                    } // Development mode: Allow direct password comparison (disable in production)
// else if (password_verify($password, $user['password_hash'])) {
if ($password === $user['password_hash']) {
                        // OTP logic removed. Straight-forward login.
                        $_SESSION['user'] = $user;
                        $stmt = $conn->prepare("UPDATE users_student SET last_active = NOW() WHERE id = ?");
                        $stmt->bind_param("s", $user['id']);
                        $stmt->execute();
                        $stmt->close();
                        
                        header("Location: " . BASE_URL . "/student/index.php");
                        exit();
                    } else {
                        $errors[] = "Incorrect password.";
                    }
                } else {
                    $errors[] = "No student account found with this email. This portal is for students; staff and clients must use their own portal.";
                }
            } catch (Exception $e) {
                $errors[] = "Database error: " . $e->getMessage();
            }
        }
    }
    else if ($action === 'verify_otp') {
        $user_otp = trim($_POST['otp'] ?? '');
        $saved_otp = $_SESSION['auth_otp'] ?? null;
        
        if (empty($user_otp)) {
            $errors[] = "OTP field cannot be empty.";
        } else if (!$saved_otp) {
            $errors[] = "OTP session expired or invalid. Please try again.";
        } else if (time() > $saved_otp['expires']) {
            $errors[] = "OTP has expired. Please request a new code.";
        } else if ($user_otp !== $saved_otp['code']) {
            $errors[] = "Invalid OTP verification code.";
        } else {
            if ($saved_otp['action'] === 'login') {
                try {
                    $stmt = $conn->prepare("SELECT * FROM users_student WHERE id = ?");
                    $stmt->bind_param("s", $saved_otp['user_id']);
                    $stmt->execute();
                    $user = $stmt->get_result()->fetch_assoc();
                    $stmt->close();
                    
                    if ($user) {
                        $_SESSION['user'] = [
                            'id' => $user['id'],
                            'email' => $user['email'],
                            'username' => $user['username'],
                            'first_name' => $user['first_name'],
                            'last_name' => $user['last_name'],
                            'role' => $user['role'],
                            'avatar' => $user['avatar']
                        ];
                        $_SESSION['last_active'] = time();
                        
                        unset($_SESSION['auth_otp'], $_SESSION['auth_otp_pending']);
                        log_activity("User Logged In", ["email" => $user['email']]);
                        
                        $redirect = $_SESSION['redirect_to'] ?? '';
                        unset($_SESSION['redirect_to']);
                        
                        if ($redirect && check_portal_access($user['role'], $redirect)) {
                            header("Location: " . $redirect);
                        } else {
                            switch ($user['role']) {
                                case 'ADMIN': case 'MANAGER': header("Location: " . BASE_URL . "/admin/index.php"); break;
                                case 'STAFF': header("Location: " . BASE_URL . "/staff/index.php"); break;
                                case 'STUDENT': header("Location: " . BASE_URL . "/student/index.php"); break;
                                case 'CLIENT': header("Location: " . BASE_URL . "/client/index.php"); break;
                            }
                        }
                        exit();
                    } else {
                        $errors[] = "User record not found.";
                    }
                } catch (Exception $e) {
                    $errors[] = "Database authentication error: " . $e->getMessage();
                }
            }
        }
    }
    else if ($action === 'resend_otp') {
        if ($awaiting_otp && $otp_email) {
            $otp = strval(mt_rand(100000, 999999));
            $_SESSION['auth_otp']['code'] = $otp;
            $_SESSION['auth_otp']['expires'] = time() + 300;
            
            $log_file = __DIR__ . '/uploads/otp_simulator.log';
            $log_msg = "[" . date('Y-m-d H:i:s') . "] RESEND OTP generated for $otp_email ($otp_action): $otp\n";
            @file_put_contents($log_file, $log_msg, FILE_APPEND);
            
            $success_msg = "A new verification code has been dispatched.";
        } else {
            $errors[] = "No active OTP transaction found.";
        }
    }
    else if ($action === 'cancel_otp') {
        unset($_SESSION['auth_otp'], $_SESSION['auth_otp_pending']);
        $awaiting_otp = false;
        $success_msg = "OTP session cancelled.";
    }
}

// Reusable classes for consistent contrast
$input_classes = "w-full px-3.5 py-3 rounded-xl border text-sm outline-none transition-all bg-slate-100 border-slate-300 text-slate-900 placeholder-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20      ";
$label_classes = "block text-[10px] font-display font-semibold uppercase tracking-[0.15em] mb-1.5 text-slate-500 ";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal Login · Royal Solutions ERP</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        display: ['Space Grotesk', 'sans-serif'],
                        sans:    ['Plus Jakarta Sans', 'sans-serif'],
                        mono:    ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        accent: { cyan: '#00F0FF', purple: '#8A2BE2' },
                        status: { success: '#00FF9D', warning: '#FFB800', danger: '#FF2A55' },
                    }
                }
            }
        }
    </script>
    <script src="https://unpkg.com/lucide@latest"></script>
    
    <style>
        *, *::before, *::after { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; -webkit-font-smoothing: antialiased; overflow-x: hidden; }
        h1,h2,h3,h4,h5,h6,.font-display { font-family: 'Space Grotesk', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }

        /* Ambient Blobs */
        .auth-bg::before {
            content: '';
            position: fixed; top: -25vh; left: -20vw;
            width: 65vw; height: 65vh;
            background: radial-gradient(ellipse, rgba(138,43,226,0.15) 0%, transparent 65%);
            pointer-events: none; z-index: 0;
            animation: blobFloat 15s ease-in-out infinite;
        }
        .auth-bg::after {
            content: '';
            position: fixed; bottom: -20vh; right: -15vw;
            width: 55vw; height: 55vh;
            background: radial-gradient(ellipse, rgba(0,240,255,0.1) 0%, transparent 65%);
            pointer-events: none; z-index: 0;
            animation: blobFloat 18s ease-in-out infinite reverse;
        }
        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(30px, 20px) scale(1.05); }
        }

        /* Neon Button with Sweep */
        .btn-neon {
            background: linear-gradient(135deg, #8A2BE2 0%, #00F0FF 100%);
            color: #07080A;
            font-weight: 700;
            font-family: 'Space Grotesk', sans-serif;
            letter-spacing: 0.05em;
            transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
            border: none;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
        }
        .btn-neon::before {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 100%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: 0.6s;
        }
        .btn-neon:hover { 
            box-shadow: 0 0 30px rgba(0,240,255,0.4), 0 0 60px rgba(138,43,226,0.3); 
            transform: translateY(-2px); 
        }
        .btn-neon:hover::before { left: 100%; }
        .btn-neon:active { transform: scale(0.97); }

        /* Animations */
        .auth-card { animation: slideUp 0.6s cubic-bezier(0.4,0,0.2,1) forwards; }
        @keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

        @keyframes orbPulse {
            0%,100% { transform: scale(1); opacity: 0.6; }
            50% { transform: scale(1.1); opacity: 0.9; }
        }
        .orb { animation: orbPulse 6s ease-in-out infinite; }

        /* OTP Input Boxes */
        .otp-box {
            width: 3.5rem; height: 4rem;
            text-align: center; font-size: 1.5rem; font-weight: 700;
            border-radius: 0.75rem;
            font-family: 'JetBrains Mono', monospace;
            transition: all 0.2s;
        }
        .otp-box:focus {
            border-color: #8A2BE2 !important;
            box-shadow: 0 0 0 3px rgba(138, 43, 226, 0.15) !important;
            background: #FFFFFF !important;
            outline: none !important;
            transform: scale(1.05);
        }

        /* Loading Spinner */
        .spinner {
            border: 2px solid rgba(0,0,0,0.1);
            border-top-color: #07080A;
            border-radius: 50%;
            width: 16px; height: 16px;
            animation: spin 0.8s linear infinite;
            display: inline-block;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body class="auth-bg bg-slate-100  text-slate-800  min-h-screen flex flex-col relative transition-colors duration-300">

    <!-- Top Bar -->
    <header class="relative z-10 px-8 py-5 flex justify-between items-center">
        <div class="flex items-center space-x-3">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 relative bg-gradient-to-br from-purple-600 to-cyan-400">
                <i data-lucide="zap" class="w-5 h-5 text-black"></i>
                <div class="absolute inset-0 rounded-xl animate-ping opacity-20 bg-cyan-400"></div>
            </div>
            <div>
                <span class="font-display font-bold text-slate-900  text-sm tracking-tight block">ROYAL SOLUTIONS</span>
                <span class="font-mono text-[9px] text-slate-500  tracking-widest">ERP v2.0 // SECURE</span>
            </div>
        </div>
    </header>

    <!-- Main Layout -->
    <main class="flex-1 flex items-center justify-center px-4 pb-12 pt-4 relative z-10">
        <div class="w-full max-w-5xl">
            
            <div class="auth-card rounded-3xl overflow-hidden flex flex-col lg:flex-row min-h-[600px] bg-white  border border-slate-200  shadow-2xl backdrop-blur-xl">
                
                <!-- LEFT PANEL -->
                <div class="lg:w-5/12 relative overflow-hidden flex flex-col justify-between p-8 lg:p-10 bg-gradient-to-br from-purple-50 via-white to-cyan-50 text-slate-900 border-r border-slate-200">

                    <div class="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                        <div class="orb w-64 h-64 rounded-full opacity-20 bg-purple-600" style="filter: blur(40px);"></div>
                    </div>

                    <div class="relative z-10">
                        <h1 class="font-display text-3xl lg:text-4xl font-bold mt-4 leading-tight">
                            Student<br><span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500">Command Center</span>
                        </h1>
                        <p class="font-mono text-xs mt-3 tracking-widest text-purple-600/70">
                            INITIALIZING SECURE SOCKET...
                        </p>
                    </div>

                    <div class="relative z-10 space-y-5 my-8">
                        <div class="flex items-start space-x-3">
                            <div class="w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center mt-0.5 border border-cyan-200 bg-cyan-50">
                                <i data-lucide="shield-check" class="w-4 h-4 text-cyan-600"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-slate-900">Quantum 2FA Protocol</p>
                                <p class="text-xs text-slate-500 mt-0.5 font-mono">OTP-verified access layers</p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <div class="w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center mt-0.5 border border-purple-200 bg-purple-50">
                                <i data-lucide="user-check" class="w-4 h-4 text-purple-600"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-slate-900">Admin-Provisioned Access</p>
                                <p class="text-xs text-slate-500 mt-0.5 font-mono">Accounts created by administration</p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <div class="w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center mt-0.5 border border-emerald-200 bg-emerald-50">
                                <i data-lucide="activity" class="w-4 h-4 text-emerald-600"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold text-slate-900">Real-Time Telemetry</p>
                                <p class="text-xs text-slate-500 mt-0.5 font-mono">Courses, grades & billing sync</p>
                            </div>
                        </div>
                    </div>

                    <div class="relative z-10">
                        <div class="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full text-xs font-mono bg-emerald-500/10 border border-emerald-500/20 text-emerald-600">
                            <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                            <span>SYSTEM ONLINE</span>
                        </div>
                    </div>
                </div>

                <!-- RIGHT PANEL -->
                <div class="lg:w-7/12 flex flex-col justify-center p-8 lg:p-10 relative bg-slate-50 ">

                    <!-- Alerts -->
                    <?php if (!empty($errors)): ?>
                        <div class="mb-5 p-3.5 rounded-xl text-sm flex items-start space-x-3 bg-red-50 border border-red-200 text-red-600    animate-shake">
                            <i data-lucide="alert-octagon" class="w-4 h-4 mt-0.5 flex-shrink-0"></i>
                            <div class="flex flex-col">
                                <?php foreach ($errors as $err): ?>
                                    <span class="font-mono text-xs"><?php echo $err; ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($success_msg)): ?>
                        <div class="mb-5 p-3.5 rounded-xl text-sm flex items-start space-x-3 bg-emerald-50 border border-emerald-200 text-emerald-700   ">
                            <i data-lucide="check-circle" class="w-4 h-4 mt-0.5 flex-shrink-0"></i>
                            <span class="font-mono text-xs"><?php echo $success_msg; ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if ($awaiting_otp): ?>
                    <!-- OTP SCREEN -->
                    <div class="text-center mb-7">
                        <div class="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg relative bg-gradient-to-br from-purple-600 to-cyan-400">
                            <i data-lucide="fingerprint" class="w-8 h-8 text-black"></i>
                            <div class="absolute inset-0 rounded-2xl animate-ping opacity-30 bg-cyan-400"></div>
                        </div>
                        <h2 class="font-display text-2xl font-bold text-slate-900 ">Biometric Verification</h2>
                        <p class="text-sm text-slate-500  mt-2 font-mono">
                            ENTER 6-DIGIT CIPHER SENT TO<br>
                            <span class="font-semibold text-cyan-600  font-mono mt-1 block tracking-wider"><?php echo sanitize($otp_email); ?></span>
                        </p>
                    </div>

                    <form action="<?php echo BASE_URL; ?>/login.php" method="POST" class="space-y-6" onsubmit="combineOtp()">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="action" value="verify_otp">
                        <input type="hidden" name="otp" id="otp-hidden">
                        
                        <div class="flex justify-center gap-2 sm:gap-3">
                            <input type="text" maxlength="1" class="otp-box bg-slate-100 border border-slate-300 text-slate-900   " data-otp="1" required>
                            <input type="text" maxlength="1" class="otp-box bg-slate-100 border border-slate-300 text-slate-900   " data-otp="2" required>
                            <input type="text" maxlength="1" class="otp-box bg-slate-100 border border-slate-300 text-slate-900   " data-otp="3" required>
                            <input type="text" maxlength="1" class="otp-box bg-slate-100 border border-slate-300 text-slate-900   " data-otp="4" required>
                            <input type="text" maxlength="1" class="otp-box bg-slate-100 border border-slate-300 text-slate-900   " data-otp="5" required>
                            <input type="text" maxlength="1" class="otp-box bg-slate-100 border border-slate-300 text-slate-900   " data-otp="6" required>
                        </div>
                        
                        <button type="submit" class="btn-neon w-full py-3.5 rounded-xl text-sm flex items-center justify-center gap-2">
                            <span>Authenticate</span>
                            <i data-lucide="arrow-right" class="w-4 h-4"></i>
                        </button>
                    </form>

                    <div class="flex justify-between items-center mt-6">
                        <form action="<?php echo BASE_URL; ?>/login.php" method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="action" value="resend_otp">
                            <button type="submit" class="flex items-center space-x-1.5 text-sm font-medium font-mono transition-colors text-cyan-600  ">
                                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                                <span>RESEND</span>
                            </button>
                        </form>
                        <form action="<?php echo BASE_URL; ?>/login.php" method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="action" value="cancel_otp">
                            <button type="submit" class="flex items-center space-x-1.5 text-sm font-mono text-slate-500  hover:text-slate-700  transition-colors">
                                <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i>
                                <span>ABORT</span>
                            </button>
                        </form>
                    </div>

                    <!-- Dev OTP Helper -->
                    <div class="mt-8 p-4 rounded-xl border border-cyan-500/10 bg-cyan-500/5">
                        <h4 class="text-[10px] font-display font-semibold uppercase tracking-widest mb-2 flex items-center space-x-1.5 text-cyan-600 ">
                            <i data-lucide="terminal" class="w-3 h-3"></i>
                            <span>DEV CONSOLE // SIMULATION MODE</span>
                        </h4>
                        <p class="text-xs text-slate-500  font-mono flex items-center gap-2">
                            OTP CIPHER:
                            <span class="font-mono font-bold px-2 py-1 rounded text-sm bg-cyan-500/10 text-cyan-600  border border-cyan-500/20 tracking-widest">
                                <?php echo $_SESSION['auth_otp']['code'] ?? '000000'; ?>
                            </span>
                        </p>
                    </div>

                    <?php else: ?>
                    <!-- STUDENT LOGIN FORM (accounts are created by the admin - no self-registration) -->
                    <div class="space-y-5">
                        <div class="mb-2">
                            <div class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[9px] font-mono font-bold uppercase tracking-widest bg-cyan-500/10 border border-cyan-500/20 text-cyan-600  mb-3">
                                <i data-lucide="graduation-cap" class="w-3 h-3"></i>
                                <span>Student Portal // Login Only</span>
                            </div>
                            <h2 class="font-display text-xl font-bold text-slate-900 ">Initialize Session</h2>
                            <p class="text-xs text-slate-500  mt-1 font-mono">SECURE STUDENT ACCESS TERMINAL...</p>
                        </div>
                        <form action="<?php echo BASE_URL; ?>/login.php" method="POST" class="space-y-4">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            <input type="hidden" name="action" value="login_submit">
                            
                            <div>
                                <label class="<?php echo $label_classes; ?>">Email Address</label>
                                <div class="relative group">
                                    <i data-lucide="mail" class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-with:text-cyan-500  transition-colors"></i>
                                    <input type="email" name="email" required placeholder="student@school.edu" class="<?php echo $input_classes; ?> pl-10 pr-4">
                                </div>
                            </div>
                            
                            <div>
                                <label class="<?php echo $label_classes; ?>">Passkey</label>
                                <div class="relative group">
                                    <i data-lucide="lock" class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-with:text-cyan-500  transition-colors"></i>
                                    <input type="password" name="password" id="login-password" required placeholder="••••••••" class="<?php echo $input_classes; ?> pl-10 pr-10">
                                    <button type="button" onclick="togglePassword('login-password', this)" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-500  transition-colors">
                                        <i data-lucide="eye" class="w-4 h-4"></i>
                                    </button>
                                </div>
                            </div>

                            <button type="submit" class="btn-neon w-full py-3.5 rounded-xl text-sm mt-2 flex items-center justify-center gap-2">
                                <span>Engage</span>
                                <i data-lucide="zap" class="w-4 h-4"></i>
                            </button>
                        </form>

                        <div class="p-3.5 rounded-xl border border-slate-200  bg-slate-100  flex items-start space-x-2.5">
                            <i data-lucide="info" class="w-4 h-4 mt-0.5 flex-shrink-0 text-slate-400 "></i>
                            <p class="text-xs text-slate-500  leading-relaxed">
                                Student accounts are created by the administration team — self-registration is not available. Contact the admin if you need access. Staff and clients sign in through their own portals.
                            </p>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </main>

    <footer class="relative z-10 text-center pb-6 text-xs text-slate-500  font-mono tracking-wider">
        // ROYAL SOLUTIONS TECHNOLOGIES © <?php echo date('Y'); ?> //
    </footer>

    <style>
        /* Shake animation for errors */
        @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-5px)} 75%{transform:translateX(5px)} }
        .animate-shake { animation: shake 0.4s; }
    </style>

    <script>
        lucide.createIcons();

        // Password Toggle
        function togglePassword(id, btn) {
            const input = document.getElementById(id);
            if (input.type === 'password') {
                input.type = 'text';
                btn.innerHTML = '<i data-lucide="eye-off" class="w-4 h-4"></i>';
            } else {
                input.type = 'password';
                btn.innerHTML = '<i data-lucide="eye" class="w-4 h-4"></i>';
            }
            lucide.createIcons();
        }

        // OTP Auto-Tab Logic
        const otpInputs = document.querySelectorAll('.otp-box');
        otpInputs.forEach((input, index) => {
            input.addEventListener('input', (e) => {
                if (input.value.length === 1 && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
            });
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && !input.value && index > 0) {
                    otpInputs[index - 1].focus();
                }
            });
            input.addEventListener('paste', (e) => {
                e.preventDefault();
                const paste = (e.clipboardData || window.clipboardData).getData('text').trim();
                if(/^\d+$/.test(paste)) {
                    paste.split('').forEach((char, i) => {
                        if (otpInputs[i]) otpInputs[i].value = char;
                    });
                    otpInputs[Math.min(paste.length, otpInputs.length - 1)].focus();
                }
            });
        });

        function combineOtp() {
            const hidden = document.getElementById('otp-hidden');
            hidden.value = Array.from(otpInputs).map(i => i.value).join('');
        }

        // Add loading state to all form submits
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', (e) => {
                const btn = form.querySelector('button[type="submit"]');
                if (btn && !btn.classList.contains('btn-neon')) return; 
                if (btn) {
                    const originalContent = btn.innerHTML;
                    btn.innerHTML = '<div class="spinner"></div> <span>PROCESSING</span>';
                    btn.disabled = true;
                    setTimeout(() => {
                        btn.innerHTML = originalContent;
                        btn.disabled = false;
                        lucide.createIcons();
                    }, 3000);
                }
            });
        });
    </script>
</body>
</html>
