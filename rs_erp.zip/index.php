<?php
// index.php — Royal Solutions landing page
require_once __DIR__ . '/includes/helpers.php';

$user = current_user();

// Logged-in users are routed straight to their portal
if ($user) {
    switch ($user['role']) {
        case 'ADMIN':
        case 'MANAGER':
            header("Location: " . BASE_URL . "/admin/index.php");
            break;
        case 'STAFF':
            header("Location: " . BASE_URL . "/staff/index.php");
            break;
        case 'STUDENT':
            header("Location: " . BASE_URL . "/student/index.php");
            break;
        case 'CLIENT':
            header("Location: " . BASE_URL . "/client/index.php");
            break;
        default:
            header("Location: " . BASE_URL . "/login.php");
            break;
    }
    exit();
}

$loginUrl = BASE_URL . '/login.php';
$clientUrl = BASE_URL . '/client/login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Royal Solutions — ERP for Learning & Business</title>
    <meta name="description" content="Royal Solutions ERP: one secure command center for student learning (LMS) and client business operations (CRM). 2FA-verified, role-based portals.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        display: ['Space Grotesk', 'sans-serif'],
                        sans:    ['Plus Jakarta Sans', 'sans-serif'],
                        mono:    ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        accent: { cyan: '#00F0FF', purple: '#8A2BE2' },
                        status: { success: '#00FF9D', warning: '#FFB800', danger: '#FF2A55' },
                    }
                }
            }
        }
    </script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        *, *::before, *::after { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; -webkit-font-smoothing: antialiased; overflow-x: hidden; }
        h1,h2,h3,h4,h5,h6,.font-display { font-family: 'Space Grotesk', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }

        /* Ambient Blobs */
        .landing-bg::before {
            content: '';
            position: fixed; top: -25vh; left: -20vw;
            width: 65vw; height: 65vh;
            background: radial-gradient(ellipse, rgba(138,43,226,0.10) 0%, transparent 65%);
            pointer-events: none; z-index: 0;
            animation: blobFloat 15s ease-in-out infinite;
        }
        .landing-bg::after {
            content: '';
            position: fixed; bottom: -20vh; right: -15vw;
            width: 55vw; height: 55vh;
            background: radial-gradient(ellipse, rgba(0,240,255,0.08) 0%, transparent 65%);
            pointer-events: none; z-index: 0;
            animation: blobFloat 18s ease-in-out infinite reverse;
        }
        @keyframes blobFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(30px, 20px) scale(1.05); }
        }

        /* Glass card — matches .glass-card in includes/header.php */
        .glass-card {
            background: #FFFFFF;
            border: 1px solid #E2E8F0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            color: #0F172A;
        }

        /* Neon Button with Sweep */
        .btn-neon {
            background: linear-gradient(135deg, #8A2BE2 0%, #00F0FF 100%);
            color: #07080A;
            font-weight: 700;
            font-family: 'Space Grotesk', sans-serif;
            letter-spacing: 0.05em;
            transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
            border: none;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
        }
        .btn-neon::before {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 100%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: 0.6s;
        }
        .btn-neon:hover {
            box-shadow: 0 0 30px rgba(0,240,255,0.4), 0 0 60px rgba(138,43,226,0.3);
            transform: translateY(-2px);
        }
        .btn-neon:hover::before { left: 100%; }
        .btn-neon:active { transform: scale(0.97); }

        /* Secondary button — matches .btn-glass in includes/header.php */
        .btn-glass {
            background: #F1F5F9;
            border: 1px solid #CBD5E1;
            color: #0F172A;
            font-weight: 700;
            font-family: 'Space Grotesk', sans-serif;
            letter-spacing: 0.05em;
            transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
            text-transform: uppercase;
        }
        .btn-glass:hover {
            background: #E2E8F0;
            color: #6D28D9;
            transform: translateY(-2px);
        }
        .btn-glass:active { transform: scale(0.97); }

        @keyframes floatY {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .float-slow { animation: floatY 6s ease-in-out infinite; }
        .float-slower { animation: floatY 8s ease-in-out infinite; }

        @keyframes riseIn {
            from { opacity: 0; transform: translateY(24px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .rise-in { animation: riseIn 0.7s cubic-bezier(0.4,0,0.2,1) both; }
        .rise-in-1 { animation-delay: 0.1s; }
        .rise-in-2 { animation-delay: 0.2s; }
        .rise-in-3 { animation-delay: 0.3s; }
    </style>
</head>
<body class="landing-bg bg-slate-50 text-slate-800 min-h-screen relative">

    <!-- ============ NAV ============ -->
    <header class="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur-xl">
        <nav class="max-w-7xl mx-auto px-5 sm:px-8 py-4 flex items-center justify-between gap-4">
            <a href="<?php echo BASE_URL; ?>/index.php" class="flex items-center space-x-3 group">
                <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 relative bg-gradient-to-br from-purple-600 to-cyan-400 group-hover:scale-105 transition-transform">
                    <i data-lucide="zap" class="w-5 h-5 text-black"></i>
                </div>
                <div>
                    <span class="font-display font-bold text-slate-900 text-sm tracking-tight block">ROYAL SOLUTIONS</span>
                    <span class="font-mono text-[9px] text-slate-500 tracking-widest">ERP v2.0 // LMS + CRM</span>
                </div>
            </a>

            <div class="hidden lg:flex items-center space-x-7 text-sm font-medium text-slate-600">
                <a href="#platform" class="hover:text-purple-600 transition-colors">Platform</a>
                <a href="#students" class="hover:text-purple-600 transition-colors">Students</a>
                <a href="#clients" class="hover:text-purple-600 transition-colors">Clients</a>
                <a href="#security" class="hover:text-purple-600 transition-colors">Security</a>
            </div>

            <div class="flex items-center gap-3">
                <a href="<?php echo $loginUrl; ?>" class="btn-glass hidden sm:inline-flex px-5 py-2.5 rounded-xl text-xs">Login</a>
                <a href="#students" class="btn-neon px-5 py-2.5 rounded-xl text-xs">Get Started</a>
            </div>
        </nav>
    </header>

    <!-- ============ HERO ============ -->
    <section class="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 pt-16 sm:pt-24 pb-14">
        <div class="grid lg:grid-cols-2 gap-14 items-center">

            <div class="rise-in">
                <div class="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full text-[10px] font-mono bg-emerald-100 border border-emerald-300 text-emerald-700 mb-6">
                    <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                    <span>SYSTEM ONLINE // ALL PORTALS DEPLOYED</span>
                </div>

                <h1 class="font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05] text-slate-900">
                    One command center for
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-fuchsia-500 to-cyan-500">learning</span>
                    &amp;
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-emerald-500">business</span>.
                </h1>

                <p class="mt-6 text-base sm:text-lg text-slate-600 max-w-xl leading-relaxed">
                    Royal Solutions runs your institution and your agency on a single secure ERP — courses,
                    grades, installments, projects, proposals and documents, all synced in real time behind
                    2FA-verified role-based access.
                </p>

                <div class="mt-9 flex flex-col sm:flex-row gap-4">
                    <a href="<?php echo $loginUrl; ?>" class="btn-neon px-7 py-3.5 rounded-xl text-sm inline-flex items-center justify-center gap-2">
                        <i data-lucide="graduation-cap" class="w-4 h-4"></i>
                        <span>Student Portal</span>
                    </a>
                    <a href="<?php echo $clientUrl; ?>" class="btn-glass px-7 py-3.5 rounded-xl text-sm inline-flex items-center justify-center gap-2">
                        <i data-lucide="briefcase" class="w-4 h-4"></i>
                        <span>Client Portal</span>
                    </a>
                </div>

                <div class="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-[11px] font-mono text-slate-500 tracking-wider">
                    <span class="inline-flex items-center gap-1.5"><i data-lucide="shield-check" class="w-3.5 h-3.5 text-cyan-600"></i>6-DIGIT 2FA</span>
                    <span class="inline-flex items-center gap-1.5"><i data-lucide="layers" class="w-3.5 h-3.5 text-purple-600"></i>ROLE-BASED ACCESS</span>
                    <span class="inline-flex items-center gap-1.5"><i data-lucide="activity" class="w-3.5 h-3.5 text-emerald-600"></i>REAL-TIME SYNC</span>
                </div>
            </div>

            <!-- Dashboard mock -->
            <div class="relative rise-in rise-in-2">
                <div class="absolute -inset-10 bg-gradient-to-br from-purple-600/15 to-cyan-400/15 blur-3xl rounded-full pointer-events-none"></div>

                <div class="relative rounded-3xl glass-card p-5 sm:p-6">
                    <div class="flex items-center justify-between mb-5">
                        <div class="flex items-center gap-1.5">
                            <span class="w-2.5 h-2.5 rounded-full bg-red-400/80"></span>
                            <span class="w-2.5 h-2.5 rounded-full bg-amber-400/80"></span>
                            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400/80"></span>
                        </div>
                        <span class="font-mono text-[9px] tracking-widest text-slate-400">ROYAL SOLUTIONS // DASHBOARD</span>
                    </div>

                    <div class="grid grid-cols-3 gap-3 mb-5">
                        <div class="rounded-xl p-3.5 bg-slate-50 border border-slate-200">
                            <p class="font-mono text-[9px] tracking-widest text-slate-400 mb-1">ENROLLMENT</p>
                            <p class="font-display font-bold text-lg text-slate-900">1,284</p>
                            <p class="text-[10px] font-mono text-emerald-600 mt-0.5">+12.4% / QTR</p>
                        </div>
                        <div class="rounded-xl p-3.5 bg-slate-50 border border-slate-200">
                            <p class="font-mono text-[9px] tracking-widest text-slate-400 mb-1">REVENUE</p>
                            <p class="font-display font-bold text-lg text-slate-900">₦4.2M</p>
                            <p class="text-[10px] font-mono text-emerald-600 mt-0.5">+8.1% / QTR</p>
                        </div>
                        <div class="rounded-xl p-3.5 bg-slate-50 border border-slate-200">
                            <p class="font-mono text-[9px] tracking-widest text-slate-400 mb-1">PROJECTS</p>
                            <p class="font-display font-bold text-lg text-slate-900">32</p>
                            <p class="text-[10px] font-mono text-cyan-600 mt-0.5">6 IN REVIEW</p>
                        </div>
                    </div>

                    <div class="space-y-4 mb-5">
                        <div>
                            <div class="flex justify-between text-[10px] font-mono tracking-widest mb-1.5">
                                <span class="text-slate-500">COURSE COMPLETION</span>
                                <span class="text-cyan-600">78%</span>
                            </div>
                            <div class="h-2 rounded-full bg-slate-200 overflow-hidden">
                                <div class="h-full w-[78%] rounded-full bg-gradient-to-r from-purple-600 to-cyan-400"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between text-[10px] font-mono tracking-widest mb-1.5">
                                <span class="text-slate-500">PROJECT DELIVERY</span>
                                <span class="text-emerald-600">92%</span>
                            </div>
                            <div class="h-2 rounded-full bg-slate-200 overflow-hidden">
                                <div class="h-full w-[92%] rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400"></div>
                            </div>
                        </div>
                    </div>

                    <div class="grid sm:grid-cols-2 gap-3">
                        <div class="rounded-xl p-3.5 flex items-start gap-3 bg-purple-50 border border-purple-200">
                            <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-purple-100 border border-purple-200">
                                <i data-lucide="calendar-clock" class="w-4 h-4 text-purple-600"></i>
                            </div>
                            <div>
                                <p class="text-xs font-semibold text-slate-800">Next lecture</p>
                                <p class="text-[10px] font-mono text-slate-500 mt-0.5">10:00 — DATA STRUCTURES</p>
                            </div>
                        </div>
                        <div class="rounded-xl p-3.5 flex items-start gap-3 bg-cyan-50 border border-cyan-200">
                            <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-cyan-100 border border-cyan-200">
                                <i data-lucide="file-check-2" class="w-4 h-4 text-cyan-600"></i>
                            </div>
                            <div>
                                <p class="text-xs font-semibold text-slate-800">Proposal approved</p>
                                <p class="text-[10px] font-mono text-slate-500 mt-0.5">REF #CL-2291 // REBRAND</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Floating chips -->
                <div class="float-slow absolute -top-7 -right-3 sm:-right-6 rounded-2xl px-4 py-3 glass-card shadow-xl flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center bg-emerald-100 border border-emerald-200">
                        <i data-lucide="shield-check" class="w-4 h-4 text-emerald-600"></i>
                    </div>
                    <div>
                        <p class="text-[11px] font-display font-bold text-slate-900">OTP Verified</p>
                        <p class="font-mono text-[9px] tracking-widest text-slate-400">2FA PROTOCOL PASSED</p>
                    </div>
                </div>
                <div class="float-slower absolute -bottom-6 -left-3 sm:-left-6 rounded-2xl px-4 py-3 glass-card shadow-xl flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center bg-purple-100 border border-purple-200">
                        <i data-lucide="user-plus" class="w-4 h-4 text-purple-600"></i>
                    </div>
                    <div>
                        <p class="text-[11px] font-display font-bold text-slate-900">New enrollment</p>
                        <p class="font-mono text-[9px] tracking-widest text-slate-400">STUD-48217 // ONLINE</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============ STATS BAND ============ -->
    <section class="relative z-10 border-y border-slate-200 bg-white/70 backdrop-blur">
        <div class="max-w-7xl mx-auto px-5 sm:px-8 py-8 grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-50 border border-slate-200">
                    <i data-lucide="boxes" class="w-5 h-5 text-purple-600"></i>
                </div>
                <div>
                    <p class="font-display font-bold text-xl text-slate-900">48+</p>
                    <p class="font-mono text-[10px] tracking-widest text-slate-500">OPERATIONAL MODULES</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-50 border border-slate-200">
                    <i data-lucide="layers" class="w-5 h-5 text-cyan-600"></i>
                </div>
                <div>
                    <p class="font-display font-bold text-xl text-slate-900">5</p>
                    <p class="font-mono text-[10px] tracking-widest text-slate-500">ROLE DIMENSIONS</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-50 border border-slate-200">
                    <i data-lucide="fingerprint" class="w-5 h-5 text-emerald-600"></i>
                </div>
                <div>
                    <p class="font-display font-bold text-xl text-slate-900">6-DIGIT</p>
                    <p class="font-mono text-[10px] tracking-widest text-slate-500">OTP ACCESS LAYER</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-50 border border-slate-200">
                    <i data-lucide="activity" class="w-5 h-5 text-amber-600"></i>
                </div>
                <div>
                    <p class="font-display font-bold text-xl text-slate-900">LIVE</p>
                    <p class="font-mono text-[10px] tracking-widest text-slate-500">FINANCE + HR TELEMETRY</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ============ AUDIENCES ============ -->
    <section id="students" class="relative z-10 scroll-mt-24 max-w-7xl mx-auto px-5 sm:px-8 py-20">
        <div class="text-center mb-12 rise-in">
            <p class="font-mono text-[10px] tracking-[0.3em] text-purple-600 mb-3">SELECT YOUR NODE</p>
            <h2 class="font-display text-3xl sm:text-4xl font-bold text-slate-900">Two portals. One brain.</h2>
            <p class="mt-4 text-slate-600 max-w-2xl mx-auto">Pick the side of Royal Solutions you live on. Both share the same secure core — different dimensions of it.</p>
        </div>

        <div class="grid lg:grid-cols-2 gap-7">

            <!-- Student card -->
            <div class="rise-in rise-in-1 rounded-3xl p-7 sm:p-9 glass-card relative overflow-hidden group hover:border-purple-400 transition-colors duration-300">
                <div class="absolute -top-20 -right-20 w-56 h-56 rounded-full bg-purple-600/10 blur-3xl group-hover:bg-purple-600/20 transition-all"></div>

                <div class="relative">
                    <div class="flex items-center gap-4 mb-6">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center bg-gradient-to-br from-purple-600 to-fuchsia-500 shadow-lg shadow-purple-500/25">
                            <i data-lucide="graduation-cap" class="w-6 h-6 text-white"></i>
                        </div>
                        <div>
                            <p class="font-mono text-[10px] tracking-widest text-purple-600">STUDENT NODE</p>
                            <h3 class="font-display text-xl font-bold text-slate-900">Learn smarter, track everything.</h3>
                        </div>
                    </div>

                    <ul class="space-y-3 mb-8">
                        <?php
                        $student_features = [
                            'Live course lessons in online, physical or hybrid mode',
                            'Assignments, grading and instant results',
                            'Verified certificates you can share in one click',
                            'Community forum with staff-moderated threads',
                            'Installment billing with Paystack receipts'
                        ];
                        foreach ($student_features as $f): ?>
                            <li class="flex items-start gap-2.5 text-sm text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 mt-0.5 text-emerald-600 flex-shrink-0"></i>
                                <span><?php echo $f; ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <div class="flex flex-col sm:flex-row gap-3.5">
                        <a href="<?php echo $loginUrl; ?>" class="btn-neon px-6 py-3 rounded-xl text-xs flex-1 inline-flex items-center justify-center gap-2">
                            <i data-lucide="log-in" class="w-4 h-4"></i>
                            <span>Student Login</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Client card -->
            <div id="clients" class="rise-in rise-in-2 rounded-3xl p-7 sm:p-9 glass-card relative overflow-hidden group hover:border-cyan-400 transition-colors duration-300 scroll-mt-24">
                <div class="absolute -top-20 -right-20 w-56 h-56 rounded-full bg-cyan-500/10 blur-3xl group-hover:bg-cyan-500/20 transition-all"></div>

                <div class="relative">
                    <div class="flex items-center gap-4 mb-6">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center bg-gradient-to-br from-cyan-500 to-emerald-500 shadow-lg shadow-cyan-500/25">
                            <i data-lucide="briefcase" class="w-6 h-6 text-slate-900"></i>
                        </div>
                        <div>
                            <p class="font-mono text-[10px] tracking-widest text-cyan-600">CLIENT NODE</p>
                            <h3 class="font-display text-xl font-bold text-slate-900">Ship projects. Own your data.</h3>
                        </div>
                    </div>

                    <ul class="space-y-3 mb-8">
                        <?php
                        $client_features = [
                            'Project proposals, scopes and status tracking',
                            'Scheduled meetings with agendas and outcomes',
                            'Private document vault with rollback history',
                            'Invoice and payment status, always up to date',
                            'Full activity timeline of every engagement'
                        ];
                        foreach ($client_features as $f): ?>
                            <li class="flex items-start gap-2.5 text-sm text-slate-600">
                                <i data-lucide="check" class="w-4 h-4 mt-0.5 text-emerald-600 flex-shrink-0"></i>
                                <span><?php echo $f; ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <div class="flex flex-col sm:flex-row gap-3.5">
                        <a href="<?php echo $clientUrl; ?>#register" class="btn-neon px-6 py-3 rounded-xl text-xs flex-1 inline-flex items-center justify-center gap-2">
                            <span>Get Started</span>
                            <i data-lucide="arrow-right" class="w-4 h-4"></i>
                        </a>
                        <a href="<?php echo $clientUrl; ?>" class="btn-glass px-6 py-3 rounded-xl text-xs flex-1 inline-flex items-center justify-center gap-2">
                            <i data-lucide="log-in" class="w-4 h-4"></i>
                            <span>Client Login</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============ PLATFORM FEATURES ============ -->
    <section id="platform" class="relative z-10 scroll-mt-24 border-y border-slate-200 bg-white/70 backdrop-blur">
        <div class="max-w-7xl mx-auto px-5 sm:px-8 py-20">
            <div class="text-center mb-12">
                <p class="font-mono text-[10px] tracking-[0.3em] text-purple-600 mb-3">THE PLATFORM</p>
                <h2 class="font-display text-3xl sm:text-4xl font-bold text-slate-900">Built like mainframe-grade infrastructure.</h2>
            </div>

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <?php
                $features = [
                    ['shield-check', 'purple', '2FA OTP Protocol', 'Every login and registration is verified with a 6-digit cipher dispatched to your registered channel. Sessions are hard-locked until it passes.'],
                    ['layers', 'cyan', 'Role-Based Dimensions', 'Admin, Manager, Staff, Student and Client each get their own portal, permissions and telemetry — no cross-contamination, no guesswork.'],
                    ['graduation-cap', 'emerald', 'Learning Core', 'Courses, lessons, assignments, grading, results and verifiable certificates, with online, physical and hybrid lecture modes.'],
                    ['briefcase', 'amber', 'Client Workspace', 'Proposals, projects, meetings and a private document vault with full rollback history for every file that crosses your desk.'],
                    ['credit-card', 'fuchsia', 'Payments & Installments', 'Paystack-secured installment tracking with fraud-proof amount verification, ownership checks and single-transaction consistency.'],
                    ['bell-ring', 'sky', 'Real-Time Notifications', 'Enrollments, submissions, approvals and payments surface as instant notifications — nothing happens off-screen.'],
                ];
                foreach ($features as [$icon, $color, $title, $desc]):
                    $border = ['purple' => 'border-purple-200', 'cyan' => 'border-cyan-200', 'emerald' => 'border-emerald-200', 'amber' => 'border-amber-200', 'fuchsia' => 'border-fuchsia-200', 'sky' => 'border-sky-200'][$color];
                    $bg     = ['purple' => 'bg-purple-50', 'cyan' => 'bg-cyan-50', 'emerald' => 'bg-emerald-50', 'amber' => 'bg-amber-50', 'fuchsia' => 'bg-fuchsia-50', 'sky' => 'bg-sky-50'][$color];
                    $text   = ['purple' => 'text-purple-600', 'cyan' => 'text-cyan-600', 'emerald' => 'text-emerald-600', 'amber' => 'text-amber-600', 'fuchsia' => 'text-fuchsia-600', 'sky' => 'text-sky-600'][$color];
                ?>
                <div class="rounded-2xl p-6 glass-card hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                    <div class="w-11 h-11 rounded-xl flex items-center justify-center <?php echo $bg; ?> mb-4 border <?php echo $border; ?>">
                        <i data-lucide="<?php echo $icon; ?>" class="w-5 h-5 <?php echo $text; ?>"></i>
                    </div>
                    <h3 class="font-display font-bold text-base text-slate-900 mb-2"><?php echo $title; ?></h3>
                    <p class="text-sm text-slate-600 leading-relaxed"><?php echo $desc; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ============ SECURITY STRIP ============ -->
    <section id="security" class="relative z-10 scroll-mt-24 max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <div class="rounded-3xl p-8 sm:p-10 glass-card relative overflow-hidden">
            <div class="absolute top-0 right-0 w-72 h-72 bg-purple-600/10 blur-3xl rounded-full pointer-events-none"></div>
            <div class="absolute bottom-0 left-0 w-72 h-72 bg-cyan-400/10 blur-3xl rounded-full pointer-events-none"></div>

            <div class="relative grid lg:grid-cols-2 gap-10 items-center">
                <div>
                    <p class="font-mono text-[10px] tracking-[0.3em] text-purple-600 mb-3">SECURITY-FIRST ARCHITECTURE</p>
                    <h2 class="font-display text-3xl font-bold leading-tight text-slate-900">Your data moves through<br><span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500">armored corridors.</span></h2>
                    <p class="mt-4 text-sm text-slate-600 leading-relaxed max-w-lg">
                        CSRF tokens guard every form, all queries are parameterized against injection,
                        payment callbacks verify amount, owner and idempotency, and every action is written
                        to an immutable activity ledger.
                    </p>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <?php
                    $sec_items = [
                        ['lock', 'CSRF Token on every form'],
                        ['database', 'Parameterized SQL queries'],
                        ['badge-check', 'Verified Paystack payments'],
                        ['file-lock-2', 'Immutable activity ledger']
                    ];
                    foreach ($sec_items as [$icon, $label]): ?>
                        <div class="rounded-xl p-4 bg-slate-50 border border-slate-200 flex items-start gap-3">
                            <i data-lucide="<?php echo $icon; ?>" class="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0"></i>
                            <p class="text-xs font-medium text-slate-700 leading-snug"><?php echo $label; ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- ============ CTA BANNER ============ -->
    <section class="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 pb-20">
        <div class="rounded-3xl p-10 sm:p-14 text-center relative overflow-hidden bg-gradient-to-br from-purple-50 via-white to-cyan-50 shadow-2xl border border-slate-200">
            <div class="absolute -top-24 left-1/2 -translate-x-1/2 w-[36rem] h-[36rem] bg-purple-400/15 blur-3xl rounded-full pointer-events-none"></div>

            <div class="relative">
                <p class="font-mono text-[10px] tracking-[0.3em] text-purple-600 mb-4">INITIATE CONNECTION</p>
                <h2 class="font-display text-3xl sm:text-5xl font-bold leading-tight max-w-3xl mx-auto text-slate-900">Let's grow your operation <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-500">together.</span></h2>
                <p class="mt-5 text-slate-600 max-w-xl mx-auto text-sm sm:text-base">Register in under two minutes. A verification cipher lands on your email, and your portal is live.</p>

                <div class="mt-9 flex flex-col sm:flex-row justify-center gap-4">
                    <a href="<?php echo $loginUrl; ?>" class="btn-neon px-8 py-4 rounded-xl text-sm inline-flex items-center justify-center gap-2">
                        <i data-lucide="graduation-cap" class="w-4 h-4"></i>
                        <span>Student Login</span>
                    </a>
                    <a href="<?php echo $clientUrl; ?>#register" class="btn-glass px-8 py-4 rounded-xl text-sm inline-flex items-center justify-center gap-2">
                        <i data-lucide="briefcase" class="w-4 h-4"></i>
                        <span>Start as a Client</span>
                    </a>
                </div>
                <p class="mt-6 font-mono text-[10px] tracking-widest text-slate-500">ALREADY REGISTERED?
                    <a href="<?php echo $loginUrl; ?>" class="text-purple-600 hover:text-purple-700 underline underline-offset-4">OPEN THE LOGIN TERMINAL →</a>
                </p>
            </div>
        </div>
    </section>

    <!-- ============ FOOTER ============ -->
    <footer class="relative z-10 bg-white text-slate-500 border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-5 sm:px-8 py-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            <div class="lg:col-span-1">
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-9 h-9 rounded-xl flex items-center justify-center bg-gradient-to-br from-purple-600 to-cyan-400">
                        <i data-lucide="zap" class="w-5 h-5 text-black"></i>
                    </div>
                    <div>
                        <span class="font-display font-bold text-slate-900 text-sm tracking-tight block">ROYAL SOLUTIONS</span>
                        <span class="font-mono text-[9px] text-purple-600/70 tracking-widest">ERP v2.0 // SECURE</span>
                    </div>
                </div>
                <p class="text-xs leading-relaxed text-slate-500">One command center for education and business operations. 2FA-verified, role-based, real-time.</p>
                <div class="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full text-[10px] font-mono bg-emerald-100 border border-emerald-300 text-emerald-700 mt-5">
                    <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                    <span>ALL SYSTEMS OPERATIONAL</span>
                </div>
            </div>

            <div>
                <h4 class="font-display font-bold text-slate-900 text-xs tracking-widest uppercase mb-4">Portals</h4>
                <ul class="space-y-2.5 text-sm">
                    <li><a href="<?php echo $loginUrl; ?>" class="hover:text-purple-600 transition-colors">Student — Login</a></li>
                    <li><a href="<?php echo $clientUrl; ?>#register" class="hover:text-purple-600 transition-colors">Client — Get Started</a></li>
                    <li><a href="<?php echo $clientUrl; ?>" class="hover:text-purple-600 transition-colors">Client — Login</a></li>
                </ul>
            </div>

            <div>
                <h4 class="font-display font-bold text-slate-900 text-xs tracking-widest uppercase mb-4">Platform</h4>
                <ul class="space-y-2.5 text-sm">
                    <li><a href="#platform" class="hover:text-purple-600 transition-colors">Features</a></li>
                    <li><a href="#students" class="hover:text-purple-600 transition-colors">Student Node</a></li>
                    <li><a href="#clients" class="hover:text-purple-600 transition-colors">Client Node</a></li>
                    <li><a href="#security" class="hover:text-purple-600 transition-colors">Security</a></li>
                </ul>
            </div>

            <div>
                <h4 class="font-display font-bold text-slate-900 text-xs tracking-widest uppercase mb-4">System</h4>
                <ul class="space-y-2.5 text-sm font-mono text-[11px] tracking-wider text-slate-500">
                    <li>ENV // PRODUCTION</li>
                    <li>UPTIME // 99.9%</li>
                    <li>PROTOCOL // HTTPS + CSRF</li>
                    <li>AUTH // OTP 6-DIGIT</li>
                </ul>
            </div>
        </div>

        <div class="border-t border-slate-200 py-5 text-center">
            <p class="font-mono text-[10px] tracking-widest text-slate-400">ROYAL SOLUTIONS TECHNOLOGIES © <?php echo date('Y'); ?> // ALL DIMENSIONS RESERVED</p>
        </div>
    </footer>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
