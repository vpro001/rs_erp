<?php
// client/index.php
require_once __DIR__ . '/../includes/auth_guard.php';
require_once __DIR__ . '/../config/db_connection.php';

$user = current_user();
$page_title = "Client Portal Dashboard";

// Get client ID
$client_id = null;
try {
    $stmt = $conn->prepare("SELECT id, company_name, contact_person FROM clients WHERE user_id = ?");
    $stmt->bind_param("s", $user['id']);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $client_id = $row['id'];
        $company_name = $row['company_name'];
        $contact_person = $row['contact_person'];
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

if (!$client_id) {
    $client_id = generate_uuid();
    $c_reg = 'CL-' . mt_rand(10000, 99999);
    $company_name = $user['first_name'] . "'s Enterprise";
    $contact_person = $user['first_name'] . ' ' . $user['last_name'];
    $stmt = $conn->prepare("INSERT INTO clients (id, user_id, client_id, company_name, contact_person) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $client_id, $user['id'], $c_reg, $company_name, $contact_person);
    $stmt->execute();
    $stmt->close();
}

// 1. Projects lists
$projects = [];
$active_projects_count = 0;
try {
    $stmt = $conn->prepare("SELECT p.*, u.first_name as supervisor_first, u.last_name as supervisor_last 
                            FROM projects p 
                            LEFT JOIN staff s ON p.supervisor_id = s.id 
                            LEFT JOIN users u ON s.user_id = u.id 
                            WHERE p.client_id = ?");
    $stmt->bind_param("s", $client_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $projects[] = $row;
        if (in_array($row['status'], ['PLANNING', 'IN_PROGRESS'])) {
            $active_projects_count++;
        }
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

// 2. Approved Proposals value
$approved_val = 0.00;
try {
    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM proposals WHERE client_id = ? AND status = 'APPROVED'");
    $stmt->bind_param("s", $client_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $approved_val = floatval($row['total']);
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

// 3. Unpaid payments due
$unpaid_dues = 0.00;
try {
    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM payments WHERE client_id = ? AND status = 'PENDING'");
    $stmt->bind_param("s", $client_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $unpaid_dues = floatval($row['total']);
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

// 4. Upcoming meetings
$meetings = [];
try {
    $stmt = $conn->prepare("SELECT m.*, u.first_name as staff_first, u.last_name as staff_last 
                            FROM meetings m 
                            LEFT JOIN staff s ON m.staff_id = s.id 
                            LEFT JOIN users u ON s.user_id = u.id 
                            WHERE m.client_id = ? AND m.status = 'SCHEDULED' 
                            ORDER BY m.meeting_date ASC LIMIT 3");
    $stmt->bind_param("s", $client_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $meetings[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

// 5. Recent milestones
$milestones = [];
if (!empty($projects)) {
    $proj_ids_str = implode("','", array_column($projects, 'id'));
    try {
        $res = $conn->query("SELECT m.*, p.title as project_title FROM project_milestones m JOIN projects p ON m.project_id = p.id WHERE m.project_id IN ('$proj_ids_str') ORDER BY m.due_date ASC LIMIT 4");
        while ($row = $res->fetch_assoc()) {
            $milestones[] = $row;
        }
    } catch (Exception $e) {
        // Ignore
    }
}

include __DIR__ . '/../includes/header.php';
?>

<!-- ── Metrics Grid ── -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">

    <!-- Active Projects -->
    <div class="glass-card card-hoverable p-6 rounded-2xl flex items-center justify-between">
        <div class="space-y-1.5">
            <span
                class="text-[10px] font-display font-semibold text-slate-400  uppercase tracking-[0.12em]">Active
                Projects</span>
            <h3 class="text-3xl font-display font-bold text-slate-900  tracking-tight">
                <?php echo $active_projects_count; ?></h3>
            <p class="text-xs text-slate-500 ">Ongoing engineering tracks</p>
        </div>
        <div
            class="w-12 h-12 rounded-xl flex items-center justify-center bg-cyan-50 text-cyan-600 border border-cyan-200">
            <i data-lucide="kanban-square" class="w-5 h-5"></i>
        </div>
    </div>

    <!-- Approved Value -->
    <div class="glass-card card-hoverable p-6 rounded-2xl flex items-center justify-between">
        <div class="space-y-1.5">
            <span
                class="text-[10px] font-display font-semibold text-slate-400  uppercase tracking-[0.12em]">Approved
                Value</span>
            <h3 class="text-3xl font-display font-bold text-slate-900  tracking-tight">
                <?php echo format_currency($approved_val); ?></h3>
            <p class="text-xs text-slate-500 ">Sum of contracted deals</p>
        </div>
        <div
            class="w-12 h-12 rounded-xl flex items-center justify-center bg-[#8A2BE2]/10 text-[#8A2BE2] border border-[#8A2BE2]/15">
            <i data-lucide="check-square" class="w-5 h-5"></i>
        </div>
    </div>

    <!-- Outstanding Invoices -->
    <div class="glass-card card-hoverable p-6 rounded-2xl flex items-center justify-between">
        <div class="space-y-1.5">
            <span
                class="text-[10px] font-display font-semibold text-slate-400  uppercase tracking-[0.12em]">Outstanding
                Invoices</span>
            <h3 class="text-3xl font-display font-bold text-[#FF2A55] tracking-tight">
                <?php echo format_currency($unpaid_dues); ?></h3>
            <p class="text-xs text-[#FF2A55] font-semibold">Dues awaiting checkout</p>
        </div>
        <div
            class="w-12 h-12 rounded-xl flex items-center justify-center bg-[#FF2A55]/8 text-[#FF2A55] border border-[#FF2A55]/15">
            <i data-lucide="wallet" class="w-5 h-5"></i>
        </div>
    </div>

    <!-- Scheduled Meetings -->
    <div class="glass-card card-hoverable p-6 rounded-2xl flex items-center justify-between">
        <div class="space-y-1.5">
            <span
                class="text-[10px] font-display font-semibold text-slate-400  uppercase tracking-[0.12em]">Upcoming
                Meetings</span>
            <h3 class="text-3xl font-display font-bold text-slate-900  tracking-tight">
                <?php echo count($meetings); ?></h3>
            <p class="text-xs text-slate-500 ">Reviews &amp; check-ins</p>
        </div>
        <div
            class="w-12 h-12 rounded-xl flex items-center justify-center bg-emerald-50 text-emerald-600 border border-emerald-200">
            <i data-lucide="video" class="w-5 h-5"></i>
        </div>
    </div>

</div>

<!-- ── Portal Layout Workspace Grid ── -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <!-- Left Workspace (Project Status Tracker & Timeline) -->
    <div class="lg:col-span-2 space-y-6">

        <!-- Active Projects List -->
        <div class="glass-card p-6 rounded-2xl">
            <h4
                class="text-base font-display font-bold text-slate-800  mb-4 flex items-center space-x-2">
                <i data-lucide="briefcase" class="w-5 h-5 text-cyan-600"></i>
                <span>Active Project Tracking Workspaces</span>
            </h4>

            <?php if (empty($projects)): ?>
                <div class="text-center py-8 text-sm text-slate-400 ">
                    <i data-lucide="briefcase" class="w-12 h-12 mx-auto mb-2 opacity-30"></i>
                    No projects found on file.
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($projects as $p): ?>
                        <div class="p-4 rounded-xl border border-slate-100 hover:border-slate-200 transition-all duration-200">
                            <div class="flex justify-between items-start mb-3">
                                <div>
                                    <h5 class="text-sm font-bold text-slate-800 ">
                                        <?php echo sanitize($p['title']); ?></h5>
                                    <div
                                        class="flex items-center space-x-2 mt-1 text-[11px] text-slate-400  font-mono">
                                        <span
                                            class="px-2 py-0.5 rounded uppercase badge-info"><?php echo sanitize($p['project_id']); ?></span>
                                        <span>&bull;</span>
                                        <span>Supervisor:
                                            <?php echo sanitize($p['supervisor_first'] . ' ' . $p['supervisor_last']); ?></span>
                                    </div>
                                </div>
                                <span class="text-[9px] font-mono font-bold px-2.5 py-1 rounded-full uppercase <?php
                                switch ($p['status']) {
                                    case 'PLANNING':
                                        echo 'badge-info';
                                        break;
                                    case 'IN_PROGRESS':
                                        echo 'badge-warning';
                                        break;
                                    case 'COMPLETED':
                                        echo 'badge-success';
                                        break;
                                    default:
                                        echo 'badge-info';
                                }
                                ?>">
                                    <?php echo sanitize($p['status']); ?>
                                </span>
                            </div>

                            <!-- Progress Bar -->
                            <div>
                                <div class="flex justify-between text-xs font-semibold mb-1">
                                    <span class="text-slate-400 ">Milestone Completion Progress</span>
                                    <span class="text-cyan-600 font-mono"><?php echo $p['progress']; ?>%</span>
                                </div>
                                <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-100">
                                    <div class="h-full rounded-full transition-all duration-300"
                                        style="width: <?php echo $p['progress']; ?>%; background: linear-gradient(90deg, #8A2BE2 0%, #00F0FF 100%);">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Project Milestone Timeline -->
        <div class="glass-card p-6 rounded-2xl">
            <h4
                class="text-base font-display font-bold text-slate-800  mb-6 flex items-center space-x-2">
                <i data-lucide="git-commit" class="w-5 h-5 text-[#8A2BE2]"></i>
                <span>Key Project Milestones Timeline</span>
            </h4>

            <?php if (empty($milestones)): ?>
                <div class="text-center py-6 text-sm text-slate-400 ">
                    No milestone schedules reported.
                </div>
            <?php else: ?>
                <div class="relative border-l border-slate-200 ml-3.5 space-y-6">
                    <?php foreach ($milestones as $m): ?>
                        <div class="relative pl-6">
                            <!-- Bullet Indicator -->
                            <span
                                class="absolute -left-2.5 top-1.5 w-5 h-5 rounded-full border-2 border-[#07080A] <?php echo $m['completed'] ? 'bg-emerald-500' : 'bg-slate-200'; ?> flex items-center justify-center text-[#07080A]">
                                <?php if ($m['completed']): ?>
                                    <i data-lucide="check" class="w-3 h-3"></i>
                                <?php endif; ?>
                            </span>

                            <div>
                                <div class="flex justify-between items-center">
                                    <h5 class="text-xs font-bold text-slate-800 ">
                                        <?php echo sanitize($m['title']); ?></h5>
                                    <span
                                        class="text-[10px] font-mono text-cyan-600/70"><?php echo date('M d, Y', strtotime($m['due_date'])); ?></span>
                                </div>
                                <p class="text-xs text-slate-500  mt-1">
                                    <?php echo sanitize($m['description']); ?></p>
                                <span
                                    class="text-[9px] font-mono text-slate-400  uppercase tracking-widest mt-1 block"><?php echo sanitize($m['project_title']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- Right Workspace (Meetings & Document vault links) -->
    <div class="space-y-6">

        <!-- Upcoming Consultations/Meetings -->
        <div class="glass-card p-6 rounded-2xl">
            <h4
                class="text-base font-display font-bold text-slate-800  mb-4 flex items-center space-x-2">
                <i data-lucide="calendar" class="w-5 h-5 text-[#8A2BE2]"></i>
                <span>Meetings &amp; Consultations</span>
            </h4>

            <?php if (empty($meetings)): ?>
                <div class="text-center py-6 text-sm text-slate-400 ">
                    No scheduled meetings.
                </div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($meetings as $meet): ?>
                        <div class="p-3.5 rounded-xl border border-slate-100 space-y-2">
                            <div class="flex justify-between items-start">
                                <h5 class="text-xs font-bold text-slate-800 ">
                                    <?php echo sanitize($meet['title']); ?></h5>
                                <span class="badge-info text-[9px] px-1.5 py-0.5 rounded font-mono uppercase">Scheduled</span>
                            </div>
                            <p class="text-[11px] text-slate-500  line-clamp-2">
                                <?php echo sanitize($meet['description']); ?></p>
                            <div
                                class="flex justify-between items-center text-[10px] text-slate-400  pt-2 border-t border-slate-100">
                                <span>With: Instructor <?php echo sanitize($meet['staff_first']); ?></span>
                                <span
                                    class="font-mono text-cyan-600/80"><?php echo date('M d, H:i', strtotime($meet['meeting_date'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Document Vault Quick Links -->
        <div class="glass-card p-6 rounded-2xl">
            <h4
                class="text-base font-display font-bold text-slate-800  mb-4 flex items-center space-x-2">
                <i data-lucide="folder-lock" class="w-5 h-5 text-emerald-600"></i>
                <span>Document Vault Uploads</span>
            </h4>

            <div class="space-y-3">
                <p class="text-xs text-slate-400  mb-2">Upload project requirement sheets, branding
                    assets, or download staging releases.</p>

                <a href="<?php echo BASE_URL; ?>/client/vault.php"
                    class="w-full flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-purple-400 transition-all duration-200">
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 rounded-lg flex items-center justify-center bg-emerald-50 text-emerald-600 border border-emerald-200">
                            <i data-lucide="file-up" class="w-4 h-4"></i>
                        </div>
                        <span class="text-xs font-semibold text-slate-700 ">Requirement
                            Documents</span>
                    </div>
                    <i data-lucide="chevron-right" class="w-4 h-4 text-slate-400 "></i>
                </a>

                <a href="<?php echo BASE_URL; ?>/client/vault.php"
                    class="w-full flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-purple-400 transition-all duration-200">
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 rounded-lg flex items-center justify-center bg-cyan-50 text-cyan-600 border border-cyan-200">
                            <i data-lucide="file-down" class="w-4 h-4"></i>
                        </div>
                        <span class="text-xs font-semibold text-slate-700 ">Deliverable
                            Deliveries</span>
                    </div>
                    <i data-lucide="chevron-right" class="w-4 h-4 text-slate-400 "></i>
                </a>
            </div>
        </div>

    </div>

</div>

<?php
include __DIR__ . '/../includes/footer.php';
?>