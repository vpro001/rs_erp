<?php
// client/proposals.php
require_once __DIR__ . '/../includes/auth_guard.php';
require_once __DIR__ . '/../config/db_connection.php';

$user = current_user();
$page_title = "CRM Proposals & Contracts";

// Get client ID
$client_id = null;
try {
    $stmt = $conn->prepare("SELECT id FROM clients WHERE user_id = ?");
    $stmt->bind_param("s", $user['id']);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $client_id = $row['id'];
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

$errors = [];
$success_msg = "";

// Handle Proposal Actions (Approve / Reject)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF validation failed.");
    }

    $proposal_id = sanitize($_POST['proposal_id'] ?? '');
    $action = $_POST['action'];

    if (empty($proposal_id)) {
        $errors[] = "Invalid proposal selection.";
    } else {
        $conn->begin_transaction();
        try {
            // Verify proposal belongs to this client and is PENDING
            $stmt = $conn->prepare("SELECT * FROM proposals WHERE id = ? AND client_id = ? AND status = 'PENDING'");
            $stmt->bind_param("ss", $proposal_id, $client_id);
            $stmt->execute();
            $prop = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$prop) {
                throw new Exception("Proposal not found or not in a pending state.");
            }

            if ($action === 'approve') {
                // Update proposal status
                $stmt = $conn->prepare("UPDATE proposals SET status = 'APPROVED', response_date = NOW() WHERE id = ?");
                $stmt->bind_param("s", $proposal_id);
                $stmt->execute();
                $stmt->close();

                // Create Project deposit invoice (50% upfront deposit)
                $deposit_amount = floatval($prop['amount']) * 0.50;
                $payment_id = generate_uuid();
                $trans_id = 'TXN-DEP-' . mt_rand(1000000, 9999999);
                $desc = "Upfront Project Deposit Invoice: " . $prop['title'];

                $stmt = $conn->prepare("INSERT INTO payments (id, transaction_id, type, amount, method, status, client_id, description, due_date) 
                                        VALUES (?, ?, 'DEPOSIT', ?, 'PAYSTACK', 'PENDING', ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))");
                $stmt->bind_param("ssdss", $payment_id, $trans_id, $deposit_amount, $client_id, $desc);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                log_activity("Approved Sales Proposal", ["proposal_id" => $proposal_id]);
                $success_msg = "You have approved the proposal! An upfront deposit invoice of " . format_currency($deposit_amount) . " has been issued to your billing ledger.";
            } else if ($action === 'reject') {
                // Update proposal status
                $stmt = $conn->prepare("UPDATE proposals SET status = 'REJECTED', response_date = NOW() WHERE id = ?");
                $stmt->bind_param("s", $proposal_id);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                log_activity("Rejected Sales Proposal", ["proposal_id" => $proposal_id]);
                $success_msg = "You have declined the proposal.";
            }
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = "Operation failed: " . $e->getMessage();
        }
    }
}

// Fetch proposals list
$proposals = [];
try {
    $stmt = $conn->prepare("SELECT p.*, u.first_name as staff_first, u.last_name as staff_last 
                            FROM proposals p 
                            LEFT JOIN staff s ON p.assigned_to = s.id 
                            LEFT JOIN users u ON s.user_id = u.id 
                            WHERE p.client_id = ? 
                            ORDER BY p.created_at DESC");
    $stmt->bind_param("s", $client_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $proposals[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

include __DIR__ . '/../includes/header.php';
?>

<!-- Info Alerts -->
<?php if (!empty($errors)): ?>
    <div
        class="mb-6 p-4 bg-red-500/10 border border-red-500/30 text-red-600  rounded-xl text-sm font-medium">
        <?php foreach ($errors as $err): ?>
            <p><?php echo $err; ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (!empty($success_msg)): ?>
    <div
        class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600  rounded-xl text-sm font-medium">
        <?php echo $success_msg; ?>
    </div>
<?php endif; ?>

<!-- Proposals grid layout -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <?php if (empty($proposals)): ?>
        <div
            class="col-span-full bg-white  border border-slate-200  p-12 text-center rounded-2xl">
            <i data-lucide="file-text" class="w-12 h-12 mx-auto mb-3 opacity-30 text-slate-400"></i>
            <h4 class="text-sm font-bold text-slate-700 ">No contract proposals issued under your
                profile.</h4>
        </div>
    <?php else: ?>
        <?php foreach ($proposals as $prop): ?>
            <div
                class="bg-white  border border-slate-200  rounded-2xl p-6 shadow-sm flex flex-col justify-between hover:scale-[1.005] transition-all">

                <div class="space-y-4">
                    <div class="flex justify-between items-start">
                        <div>
                            <span
                                class="text-[9px] bg-slate-100  px-2.5 py-0.5 rounded font-mono text-slate-450 uppercase font-semibold">
                                <?php echo sanitize($prop['proposal_id']); ?>
                            </span>
                            <h4 class="text-base font-bold text-slate-905  mt-1.5">
                                <?php echo sanitize($prop['title']); ?></h4>
                        </div>

                        <span class="px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider <?php
                        switch ($prop['status']) {
                            case 'PENDING':
                                echo 'bg-amber-500/10 text-amber-600 ';
                                break;
                            case 'APPROVED':
                                echo 'bg-emerald-500/10 text-emerald-600 ';
                                break;
                            case 'REJECTED':
                                echo 'bg-red-500/10 text-red-600 ';
                                break;
                            default:
                                echo 'bg-slate-100 text-slate-500  ';
                        }
                        ?>">
                            <?php echo sanitize($prop['status']); ?>
                        </span>
                    </div>

                    <p class="text-xs text-slate-500  leading-relaxed">
                        <?php echo sanitize($prop['description']); ?></p>

                    <!-- Services Tags list -->
                    <div>
                        <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1.5">Deliverables
                            Coverage</span>
                        <div class="flex flex-wrap gap-1.5">
                            <?php
                            $services = json_decode($prop['services'], true);
                            if ($services):
                                foreach ($services as $srv):
                                    ?>
                                    <span
                                        class="bg-indigo-500/5 text-indigo-650  px-2.5 py-0.5 rounded text-[10px] border border-indigo-500/10 font-medium">
                                        <?php echo sanitize($srv); ?>
                                    </span>
                                <?php endforeach; endif; ?>
                        </div>
                    </div>

                    <!-- Timelines & Manager -->
                    <div
                        class="grid grid-cols-2 gap-4 text-[10px] text-slate-400 border-t border-slate-100  pt-3">
                        <div>
                            <span class="font-bold block uppercase tracking-wider text-slate-450">Estimated Timeline</span>
                            <span
                                class="text-slate-700  font-semibold mt-0.5 block"><?php echo sanitize($prop['timeline']); ?></span>
                        </div>
                        <div>
                            <span class="font-bold block uppercase tracking-wider text-slate-455">Assigned Lead Architect</span>
                            <span class="text-slate-700  font-semibold mt-0.5 block">Instructor:
                                <?php echo sanitize($prop['staff_first'] ?? 'Staff Lead'); ?></span>
                        </div>
                    </div>
                </div>

                <div class="border-t border-slate-100  mt-5 pt-4 flex items-center justify-between">
                    <div>
                        <span class="text-[9px] text-slate-400 uppercase font-bold block">Proposed Budget</span>
                        <span
                            class="text-base font-bold text-slate-900 "><?php echo format_currency($prop['amount']); ?></span>
                    </div>

                    <?php if ($prop['status'] === 'PENDING'): ?>
                        <div class="flex space-x-2">
                            <form action="proposals.php" method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="proposal_id" value="<?php echo $prop['id']; ?>">
                                <button type="submit"
                                    class="px-3.5 py-2 border border-red-500/30 hover:bg-red-500/5 text-red-600  font-bold rounded-xl text-xs transition-colors">
                                    Decline
                                </button>
                            </form>

                            <form action="proposals.php" method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="proposal_id" value="<?php echo $prop['id']; ?>">
                                <button type="submit"
                                    class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-colors shadow-sm">
                                    Accept & Sign
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <span class="text-[10px] text-slate-400">
                            Responded Date: <?php echo date('M d, Y', strtotime($prop['response_date'])); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php
include __DIR__ . '/../includes/footer.php';
?>