<?php
// client/onboarding.php
require_once __DIR__ . '/../includes/auth_guard.php';
require_once __DIR__ . '/../config/db_connection.php';

$user = current_user();
$page_title = "Onboarding Questionnaire Wizard";

// Get client ID
$client_id = null;
try {
    $stmt = $conn->prepare("SELECT id FROM clients WHERE user_id = ?");
    $stmt->bind_param("s", $user['id']);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $client_id = $row['id'];
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

if (!$client_id) {
    $client_id = generate_uuid();
    $c_reg = 'CL-' . mt_rand(10000, 99999);
    $company_name = $user['first_name'] . "'s Enterprise";
    $contact_person = $user['first_name'] . ' ' . $user['last_name'];
    $stmt = $conn->prepare("INSERT INTO clients (id, user_id, client_id, company_name, contact_person) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $client_id, $user['id'], $c_reg, $company_name, $contact_person);
    $stmt->execute();
    $stmt->close();
}

$errors = [];
$success_msg = "";

// Handle submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_wizard') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF validation failed.");
    }

    $project_title = sanitize($_POST['project_title'] ?? '');
    $category = sanitize($_POST['category'] ?? 'General');
    $platform = sanitize($_POST['platform'] ?? 'Web');
    $timeline = sanitize($_POST['timeline'] ?? '1-3 months');
    $budget_limit = floatval($_POST['budget_limit'] ?? 0);
    $features = $_POST['features'] ?? [];

    if (empty($project_title)) {
        $errors[] = "Project Title is required.";
    } else {
        try {
            $questionnaire_id = generate_uuid();

            // Build dynamic pricing/milestones server-side to enforce integrity
            $base_platform_fees = ['web' => 1500, 'mobile' => 2500, 'hybrid' => 3500, 'desktop' => 4000];
            $base_cat_fees = ['ecommerce' => 1000, 'saas' => 2000, 'erp' => 3500, 'custom' => 2500, 'lms' => 1500];
            $feature_fees = [
                'user_mgmt' => 400,
                'payments' => 600,
                'realtime' => 700,
                'analytics' => 800,
                'documents' => 500,
                'scheduling' => 450
            ];

            $est_budget = ($base_platform_fees[strtolower($platform)] ?? 1500) + ($base_cat_fees[strtolower($category)] ?? 1000);
            foreach ($features as $f) {
                if (isset($feature_fees[$f])) {
                    $est_budget += $feature_fees[$f];
                }
            }

            $timeline_multipliers = ['under_1' => 1.3, '1-3' => 1.0, '3-6' => 0.95, '6_plus' => 0.9];
            $multiplier = $timeline_multipliers[$timeline] ?? 1.0;
            $est_budget = round($est_budget * $multiplier, 2);

            $estimated_milestones = [
                [
                    "title" => "UX/UI Design & System Architecture",
                    "budget" => round($est_budget * 0.15, 2),
                    "description" => "Creation of interactive Figma wireframes, prototype flows, and system db structure design."
                ],
                [
                    "title" => "Core Backend & Database Setup",
                    "budget" => round($est_budget * 0.35, 2),
                    "description" => "Setup of backend servers, API framework, relational database models, and initial auth flows."
                ],
                [
                    "title" => "Feature Integrations & Gateway Hook",
                    "budget" => round($est_budget * 0.30, 2),
                    "description" => "Developing user features, real-time channels, analytics dashboards, and payment callbacks."
                ],
                [
                    "title" => "Testing, QA Deployment & UAT Signoff",
                    "budget" => round($est_budget * 0.20, 2),
                    "description" => "Running Unit/Integration testing suites, security hardening, final server migration, and launch."
                ]
            ];

            // Format JSON data
            $questions_data = [
                "title" => "Standard CRM Client Onboarding Assessment Wizard",
                "version" => "1.0",
                "sections" => ["Project Specs", "Feature Board", "Timeline & Cost Scope"]
            ];

            $responses_data = [
                "inputs" => [
                    "project_title" => $project_title,
                    "category" => $category,
                    "platform" => $platform,
                    "timeline" => $timeline,
                    "target_budget" => $budget_limit,
                    "features_selected" => $features
                ],
                "estimations" => [
                    "calculated_budget" => $est_budget,
                    "milestones" => $estimated_milestones
                ]
            ];

            $questions_json = json_encode($questions_data);
            $responses_json = json_encode($responses_data);

            $stmt = $conn->prepare("INSERT INTO questionnaires (id, client_id, title, questions, responses, completed_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("sssss", $questionnaire_id, $client_id, $project_title, $questions_json, $responses_json);
            $stmt->execute();
            $stmt->close();

            // Add a notification for managers/admins
            // Fetch any admin or manager to notify
            $admin_res = $conn->query("SELECT id FROM users WHERE role IN ('ADMIN', 'MANAGER') LIMIT 5");
            while ($admin_row = $admin_res->fetch_assoc()) {
                send_notification(
                    $admin_row['id'],
                    "New Onboarding Questionnaire Submitted",
                    "Client has submitted Onboarding Specs for project: '$project_title' with budget estimate " . format_currency($est_budget),
                    "CRM",
                    "HIGH"
                );
            }

            log_activity("Completed Onboarding Wizard questionnaire", ["project" => $project_title, "est_budget" => $est_budget]);
            $success_msg = "Your project specs have been registered! Our advisors have been notified and will review your estimates.";

        } catch (Exception $e) {
            $errors[] = "Failed to submit assessment specs: " . $e->getMessage();
        }
    }
}

// Fetch past questionnaire submissions
$history = [];
try {
    $stmt = $conn->prepare("SELECT * FROM questionnaires WHERE client_id = ? ORDER BY completed_at DESC");
    $stmt->bind_param("s", $client_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $history[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    // Ignore
}

include __DIR__ . '/../includes/header.php';
?>

<!-- Alerts -->
<?php if (!empty($errors)): ?>
    <div
        class="mb-6 p-4 bg-red-500/10 border border-red-500/30 text-red-600  rounded-xl text-sm font-medium">
        <?php foreach ($errors as $err): ?>
            <p><?php echo $err; ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (!empty($success_msg)): ?>
    <div
        class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600  rounded-xl text-sm font-medium">
        <?php echo $success_msg; ?>
    </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <!-- Left 2 Cols: Onboarding Form Wizard -->
    <div class="lg:col-span-2 space-y-6">

        <div
            class="bg-white  border border-slate-200  rounded-2xl p-6 shadow-sm">
            <h4
                class="text-sm font-bold text-slate-900  mb-6 flex items-center space-x-2 border-b border-slate-100  pb-3">
                <i data-lucide="sparkles" class="w-4 h-4 text-blue-500"></i>
                <span>Interactive Requirement Estimator Wizard</span>
            </h4>

            <!-- Multi-step tabs headers -->
            <div
                class="flex items-center justify-between border-b border-slate-100  pb-4 mb-6 text-xs font-semibold text-slate-400 select-none">
                <div id="tab-step-1" class="flex items-center space-x-1.5 text-blue-600 ">
                    <span
                        class="w-5 h-5 flex items-center justify-center rounded-full bg-blue-500/10 text-[10px] font-bold ring-2 ring-blue-500/20">1</span>
                    <span>Project Meta</span>
                </div>
                <div class="h-px bg-slate-200  flex-1 mx-4"></div>
                <div id="tab-step-2" class="flex items-center space-x-1.5">
                    <span
                        class="w-5 h-5 flex items-center justify-center rounded-full bg-slate-100  text-[10px] font-bold">2</span>
                    <span>Feature Boards</span>
                </div>
                <div class="h-px bg-slate-200  flex-1 mx-4"></div>
                <div id="tab-step-3" class="flex items-center space-x-1.5">
                    <span
                        class="w-5 h-5 flex items-center justify-center rounded-full bg-slate-100  text-[10px] font-bold">3</span>
                    <span>Estimation Review</span>
                </div>
            </div>

            <form action="onboarding.php" method="POST" id="wizard-form" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" name="action" value="submit_wizard">

                <!-- STEP 1 CONTAINER -->
                <div id="step-1" class="space-y-4">
                    <div
                        class="bg-blue-500/5 p-4 rounded-xl border border-blue-500/10 text-xs text-slate-500 ">
                        <span class="font-bold text-blue-600  block mb-1">Let's map your application
                            specifications!</span>
                        Fill in standard credentials to calculate project structural complexity, pricing outlines, and
                        agile milestones automatically.
                    </div>

                    <div>
                        <label for="p-title"
                            class="block text-[10px] font-semibold text-slate-455  uppercase tracking-wider mb-1.5">Project
                            / Application Title</label>
                        <input type="text" name="project_title" id="p-title" required
                            placeholder="e.g. Royal Solutions CRM Platform..."
                            class="w-full px-4 py-2.5 bg-slate-50  border border-slate-200  rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-xs transition-all">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="p-cat"
                                class="block text-[10px] font-semibold text-slate-455  uppercase tracking-wider mb-1.5">Application
                                Category</label>
                            <select name="category" id="p-cat" onchange="calculateEstimates()"
                                class="w-full px-4 py-2.5 bg-slate-50  border border-slate-200  rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-xs transition-all">
                                <option value="ecommerce">E-Commerce & Digital Store ($1,000 base)</option>
                                <option value="saas">Software-as-a-Service SaaS ($2,000 base)</option>
                                <option value="erp">Operational ERP Portal ($3,500 base)</option>
                                <option value="lms">Learning Management LMS ($1,500 base)</option>
                                <option value="custom">Custom Enterprise Solution ($2,500 base)</option>
                            </select>
                        </div>

                        <div>
                            <label for="p-plat"
                                class="block text-[10px] font-semibold text-slate-455  uppercase tracking-wider mb-1.5">Platform
                                Delivery</label>
                            <select name="platform" id="p-plat" onchange="calculateEstimates()"
                                class="w-full px-4 py-2.5 bg-slate-50  border border-slate-200  rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-xs transition-all">
                                <option value="web">Web Application Engine ($1,500 base)</option>
                                <option value="mobile">Native Mobile App (iOS/Android) ($2,500 base)</option>
                                <option value="hybrid">Cross-Platform Web + Mobile ($3,500 base)</option>
                                <option value="desktop">Native Desktop Client ($4,000 base)</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex justify-end pt-4">
                        <button type="button" onclick="goToStep(2)"
                            class="px-5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl text-xs transition-all shadow-md">
                            Continue: Features
                        </button>
                    </div>
                </div>

                <!-- STEP 2 CONTAINER -->
                <div id="step-2" class="hidden space-y-4">
                    <h5 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Select Platform
                        Integrations</h5>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                        <!-- Box: User management -->
                        <label
                            class="p-4 bg-slate-50  hover:bg-slate-100  border border-slate-200  rounded-xl flex items-start space-x-3 cursor-pointer select-none">
                            <input type="checkbox" name="features[]" value="user_mgmt" checked
                                onchange="calculateEstimates()"
                                class="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300">
                            <div>
                                <span class="text-xs font-bold text-slate-800  block">User Management
                                    & Auth (+$400)</span>
                                <p class="text-[10px] text-slate-400 mt-0.5">Role-based accounts, signups, profile
                                    pages, and 2FA settings.</p>
                            </div>
                        </label>

                        <!-- Box: Payments -->
                        <label
                            class="p-4 bg-slate-50  hover:bg-slate-100  border border-slate-200  rounded-xl flex items-start space-x-3 cursor-pointer select-none">
                            <input type="checkbox" name="features[]" value="payments" checked
                                onchange="calculateEstimates()"
                                class="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300">
                            <div>
                                <span class="text-xs font-bold text-slate-800  block">Payment
                                    Gateways Hook (+$600)</span>
                                <p class="text-[10px] text-slate-400 mt-0.5">Stripe, Paystack callbacks, automatic
                                    invoicing, and installments.</p>
                            </div>
                        </label>

                        <!-- Box: Realtime -->
                        <label
                            class="p-4 bg-slate-50  hover:bg-slate-100  border border-slate-200  rounded-xl flex items-start space-x-3 cursor-pointer select-none">
                            <input type="checkbox" name="features[]" value="realtime" onchange="calculateEstimates()"
                                class="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300">
                            <div>
                                <span class="text-xs font-bold text-slate-800  block">Real-time
                                    Channels / Chat (+$700)</span>
                                <p class="text-[10px] text-slate-400 mt-0.5">Instant peer chats, live notifications
                                    stream, and SSE events.</p>
                            </div>
                        </label>

                        <!-- Box: Analytics -->
                        <label
                            class="p-4 bg-slate-50  hover:bg-slate-100  border border-slate-200  rounded-xl flex items-start space-x-3 cursor-pointer select-none">
                            <input type="checkbox" name="features[]" value="analytics" onchange="calculateEstimates()"
                                class="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300">
                            <div>
                                <span class="text-xs font-bold text-slate-800  block">Data Reports &
                                    Charts (+$800)</span>
                                <p class="text-[10px] text-slate-400 mt-0.5">Interactive graphs, ledger balances, CSV
                                    export, and dashboards.</p>
                            </div>
                        </label>

                        <!-- Box: Documents -->
                        <label
                            class="p-4 bg-slate-50  hover:bg-slate-100  border border-slate-200  rounded-xl flex items-start space-x-3 cursor-pointer select-none">
                            <input type="checkbox" name="features[]" value="documents" onchange="calculateEstimates()"
                                class="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300">
                            <div>
                                <span class="text-xs font-bold text-slate-800  block">File Vault &
                                    Versioning (+$500)</span>
                                <p class="text-[10px] text-slate-400 mt-0.5">Document uploads, drag-drop folders,
                                    version archives, rollbacks.</p>
                            </div>
                        </label>

                        <!-- Box: Scheduling -->
                        <label
                            class="p-4 bg-slate-50  hover:bg-slate-100  border border-slate-200  rounded-xl flex items-start space-x-3 cursor-pointer select-none">
                            <input type="checkbox" name="features[]" value="scheduling" onchange="calculateEstimates()"
                                class="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300">
                            <div>
                                <span class="text-xs font-bold text-slate-800  block">Meeting &
                                    Calendar Scheduler (+$450)</span>
                                <p class="text-[10px] text-slate-400 mt-0.5">Coordinate calls, calendar integration,
                                    Jitsi meet embed links.</p>
                            </div>
                        </label>

                    </div>

                    <div class="flex justify-between pt-4">
                        <button type="button" onclick="goToStep(1)"
                            class="px-5 py-2 bg-slate-100  hover:bg-slate-200  text-slate-700  font-semibold rounded-xl text-xs transition-all">
                            Back: Metadata
                        </button>
                        <button type="button" onclick="goToStep(3)"
                            class="px-5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl text-xs transition-all shadow-md">
                            Continue: Review
                        </button>
                    </div>
                </div>

                <!-- STEP 3 CONTAINER -->
                <div id="step-3" class="hidden space-y-6">
                    <h5
                        class="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100  pb-2">
                        Timeline Scope & Review</h5>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        <div>
                            <label for="p-timeline"
                                class="block text-[10px] font-semibold text-slate-455  uppercase tracking-wider mb-1.5">Project
                                Development Phase</label>
                            <select name="timeline" id="p-timeline" onchange="calculateEstimates()"
                                class="w-full px-4 py-2.5 bg-slate-50  border border-slate-200  rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-xs transition-all">
                                <option value="under_1">Rush Delivery (Under 1 month, 1.3x speed fee)</option>
                                <option value="1-3">Standard Velocity (1-3 months, 1.0x factor)</option>
                                <option value="3-6">Regular Phase (3-6 months, 0.95x discount)</option>
                                <option value="6_plus">Long Term Agile (6+ months, 0.90x discount)</option>
                            </select>
                        </div>

                        <div>
                            <label for="p-budget-limit"
                                class="block text-[10px] font-semibold text-slate-455  uppercase tracking-wider mb-1.5">Your
                                Target Budget Cap ($)</label>
                            <input type="number" name="budget_limit" id="p-budget-limit" value="5000"
                                placeholder="e.g. 5000"
                                class="w-full px-4 py-2.5 bg-slate-50  border border-slate-200  rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-xs transition-all">
                        </div>

                    </div>

                    <!-- Dynamic review box -->
                    <div class="p-5 bg-blue-500/5  rounded-2xl border border-blue-500/10 space-y-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <h5 class="text-xs font-bold text-slate-900 ">Estimated Project Budget
                                </h5>
                                <p class="text-[10px] text-slate-400">Calculated according to selected specifications
                                </p>
                            </div>
                            <span id="calculated-budget-display"
                                class="text-lg font-bold text-blue-600  font-mono">$0.00</span>
                        </div>

                        <div class="border-t border-slate-200/50  pt-4 space-y-2">
                            <h6
                                class="text-[10px] font-bold text-slate-500  uppercase tracking-wider">
                                Suggested Agile Milestones</h6>

                            <div id="suggested-milestones-container" class="space-y-3 pt-2">
                                <!-- Dynamically loaded milestones go here -->
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-between pt-4">
                        <button type="button" onclick="goToStep(2)"
                            class="px-5 py-2 bg-slate-100  hover:bg-slate-200  text-slate-700  font-semibold rounded-xl text-xs transition-all">
                            Back: Features
                        </button>
                        <button type="submit"
                            class="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-650 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-emerald-500/10">
                            Submit specs to Advisor
                        </button>
                    </div>
                </div>
            </form>
        </div>

    </div>

    <!-- Right Panel: History of Submissions -->
    <div class="space-y-6">
        <div
            class="bg-white  border border-slate-200  rounded-2xl p-6 shadow-sm">
            <h4
                class="text-sm font-bold text-slate-900  mb-6 flex items-center space-x-2 border-b border-slate-100  pb-3">
                <i data-lucide="folder" class="w-4 h-4 text-indigo-500"></i>
                <span>Past Assessments Feed</span>
            </h4>

            <?php if (empty($history)): ?>
                <div class="text-center py-8 text-xs text-slate-450">
                    No onboarding evaluations logged.
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($history as $h):
                        $resp = json_decode($h['responses'], true);
                        $calc_budget = $resp['estimations']['calculated_budget'] ?? 0;
                        ?>
                        <div
                            class="p-4 bg-slate-50  border border-slate-150  rounded-xl space-y-2">
                            <div class="flex justify-between items-start">
                                <h5 class="text-xs font-bold text-slate-900  line-clamp-1 pr-2">
                                    <?php echo sanitize($h['title']); ?></h5>
                                <span
                                    class="text-[9px] font-bold text-blue-600  font-mono"><?php echo format_currency($calc_budget); ?></span>
                            </div>

                            <p class="text-[10px] text-slate-400">Submitted:
                                <?php echo date('M d, Y', strtotime($h['completed_at'])); ?></p>

                            <!-- Toggle button to view results detail -->
                            <button onclick="toggleSpecDetail('<?php echo $h['id']; ?>')"
                                class="text-[9px] font-bold text-indigo-600  hover:underline flex items-center space-x-0.5 pt-1">
                                <span>Inspect suggested milestones</span>
                                <i data-lucide="chevron-down" class="w-3 h-3"></i>
                            </button>

                            <!-- Hidden Spec Details -->
                            <div id="spec-<?php echo $h['id']; ?>"
                                class="hidden border-t border-slate-200/50  pt-2.5 space-y-2 mt-2">
                                <?php foreach (($resp['estimations']['milestones'] ?? []) as $index => $m): ?>
                                    <div class="text-[10px]">
                                        <span
                                            class="font-bold text-slate-800  block">M<?php echo ($index + 1); ?>:
                                            <?php echo sanitize($m['title']); ?></span>
                                        <span
                                            class="text-[9px] text-slate-400 block"><?php echo sanitize($m['description']); ?></span>
                                        <span
                                            class="text-[9px] font-mono text-blue-500 font-bold"><?php echo format_currency($m['budget']); ?>
                                            allocation</span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<script>
    // Wizard Steps navigation
    function goToStep(step) {
        // Validation check for step 1
        if (step === 2) {
            const titleInput = document.getElementById('p-title');
            if (!titleInput.value) {
                titleInput.reportValidity();
                return;
            }
        }

        // Hide all steps
        document.getElementById('step-1').classList.add('hidden');
        document.getElementById('step-2').classList.add('hidden');
        document.getElementById('step-3').classList.add('hidden');

        // Remove class active on tabs
        document.getElementById('tab-step-1').classList.remove('text-blue-600', '');
        document.getElementById('tab-step-2').classList.remove('text-blue-600', '');
        document.getElementById('tab-step-3').classList.remove('text-blue-600', '');

        // Set rings color logic
        setTabRing(1, false);
        setTabRing(2, false);
        setTabRing(3, false);

        // Show selected step
        document.getElementById('step-' + step).classList.remove('hidden');
        document.getElementById('tab-step-' + step).classList.add('text-blue-600', '');
        setTabRing(step, true);

        if (step === 3) {
            calculateEstimates();
        }
    }

    function setTabRing(step, active) {
        const tab = document.getElementById('tab-step-' + step);
        if (!tab) return;
        const ring = tab.querySelector('span');
        if (active) {
            ring.className = "w-5 h-5 flex items-center justify-center rounded-full bg-blue-500/10 text-[10px] font-bold ring-2 ring-blue-500/20";
        } else {
            ring.className = "w-5 h-5 flex items-center justify-center rounded-full bg-slate-100  text-[10px] font-bold";
        }
    }

    function calculateEstimates() {
        const platform = document.getElementById('p-plat').value;
        const category = document.getElementById('p-cat').value;
        const timeline = document.getElementById('p-timeline').value;

        // Base Fees
        const basePlatformFees = { web: 1500, mobile: 2500, hybrid: 3500, desktop: 4000 };
        const baseCatFees = { ecommerce: 1000, saas: 2000, erp: 3500, lms: 1500, custom: 2500 };

        // Feature checkbox fees
        const featureFees = {
            user_mgmt: 400,
            payments: 600,
            realtime: 700,
            analytics: 800,
            documents: 500,
            scheduling: 450
        };

        let budget = (basePlatformFees[platform] || 1500) + (baseCatFees[category] || 1000);

        // Loop checked features
        const checkedFeatures = document.querySelectorAll('input[name="features[]"]:checked');
        checkedFeatures.forEach(chk => {
            if (featureFees[chk.value]) {
                budget += featureFees[chk.value];
            }
        });

        // Timeline multipliers
        const timelineMultipliers = { under_1: 1.3, '1-3': 1.0, '3-6': 0.95, '6_plus': 0.9 };
        const mult = timelineMultipliers[timeline] || 1.0;

        const finalBudget = Math.round(budget * mult);

        // Display Budget
        document.getElementById('calculated-budget-display').textContent = '$' + finalBudget.toLocaleString('en-US', { minimumFractionDigits: 2 });

        // Generate Milestones html
        const milestones = [
            {
                title: "UX/UI Design & System Architecture",
                budget: Math.round(finalBudget * 0.15),
                desc: "Interactive wireframes design and schema layout blueprints."
            },
            {
                title: "Core Backend & Database Setup",
                budget: Math.round(finalBudget * 0.35),
                desc: "API endpoints deployment and core authentication integration."
            },
            {
                title: "Feature Integrations & Gateway Hook",
                budget: Math.round(finalBudget * 0.30),
                desc: "Developing checked features dashboards and transactional gateways."
            },
            {
                title: "Testing, QA Deployment & UAT Signoff",
                budget: Math.round(finalBudget * 0.20),
                desc: "Security audit compliance checks, QA tests and final server deployment."
            }
        ];

        const container = document.getElementById('suggested-milestones-container');
        container.innerHTML = '';

        milestones.forEach((m, idx) => {
            container.innerHTML += `
                <div class="p-3 bg-white  border border-slate-150  rounded-xl flex justify-between items-start">
                    <div class="space-y-0.5">
                        <span class="text-[10px] font-bold text-slate-800 ">M${idx + 1}: ${m.title}</span>
                        <p class="text-[9px] text-slate-400">${m.desc}</p>
                    </div>
                    <span class="text-[10px] font-bold text-blue-500  font-mono">$${m.budget.toLocaleString()}</span>
                </div>
            `;
        });
    }

    function toggleSpecDetail(id) {
        const detail = document.getElementById('spec-' + id);
        if (detail) {
            detail.classList.toggle('hidden');
        }
    }
</script>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>