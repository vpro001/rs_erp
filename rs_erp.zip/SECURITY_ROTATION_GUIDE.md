# Security Rotation Guide - Royal Solutions ERP (PHP)

**Last Updated**: October 28, 2025  
**Version**: 1.0

---

## ⚠️ IMPORTANT: READ THIS FIRST

This guide covers the **mandatory credential rotation** required if credentials were exposed in git history. You **MUST** rotate all credentials listed below before deploying to production.

**Note**: This project uses PHP configuration files (`config/app_config.php` and `config/app_config.local.php`) instead of `.env` files. All credentials are stored in PHP arrays.

---

## 🔐 Credentials Requiring Rotation

### 1. Database Credentials
**Location**: `config/app_config.php` (or `config/app_config.local.php`)
```php
'database' => [
    'host' => 'localhost',
    'name' => 'rs_erp',
    'user' => 'root',
    'pass' => 'YOUR_PASSWORD_HERE',  // <-- ROTATE THIS
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
],
```
**Action Required**:
1. Generate new database password
2. Update MySQL user password: `ALTER USER 'username'@'localhost' IDENTIFIED BY 'new_strong_password';`
3. Update `config/app_config.local.php` with new password (never commit this file)
4. Update all deployment environments (production, staging)

### 2. Paystack API Keys
**Location**: `config/app_config.php` (or `config/app_config.local.php`)
```php
'paystack' => [
    'public_key' => 'pk_test_xxxxxxxxxxxxxxxx',  // <-- ROTATE
    'secret_key' => 'sk_test_xxxxxxxxxxxxxxxx',  // <-- ROTATE THIS (critical!)
    'webhook_secret' => '',  // <-- ROTATE if using webhooks
],
```
**Action Required**:
1. Log into [Paystack Dashboard](https://dashboard.paystack.com/)
2. Go to Settings → API Keys & Webhooks
3. Click "Regenerate Secret Key"
4. Update `config/app_config.local.php` with new secret key
5. Update webhook URL if domain changed
6. Test payment flow in staging

### 3. Email/SMTP Credentials
**Location**: `config/app_config.php` (or `config/app_config.local.php`)
```php
'mail' => [
    'mailer' => 'smtp',
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'your_email@gmail.com',  // <-- Update if changed
    'password' => 'your_app_password',     // <-- ROTATE THIS
    'encryption' => 'tls',
    'from_address' => 'your_email@gmail.com',
    'from_name' => 'Royal Solutions ERP',
],
```
**Action Required**:
1. Generate new SMTP password/app password
2. For Gmail: Create new App Password in Google Account Security
3. For other providers: Regenerate SMTP credentials
4. Update `config/app_config.local.php` with new credentials
5. Test email sending

### 4. Application Encryption Key
**Location**: `config/app_config.php` (or `config/app_config.local.php`)
```php
'app' => [
    'key' => '',  // <-- ROTATE THIS (32-char hex)
],
```
**Action Required**:
1. Generate new 32-character key: `openssl rand -hex 32`
2. Update `config/app_config.local.php` with new key
3. **NOTE**: This will invalidate all existing sessions and encrypted data

### 5. Session/Cookie Secrets
**Location**: `config/app_config.php` (or `config/app_config.local.php`)
```php
'session' => [
    'secret' => '',  // <-- ROTATE THIS (32-char hex)
],
```
**Action Required**:
1. Generate new secret: `openssl rand -hex 32`
2. Update `config/app_config.local.php` with new secret
3. All users will be logged out

---

## 📋 Step-by-Step Rotation Process

### Phase 1: Preparation (Do this first)
```bash
# 1. Check current git status
git status

# 2. Verify config files are NOT tracked (should be in .gitignore)
git ls-files | grep "app_config"
# Should return nothing for .local.php files

# 3. Backup current config (securely)
cp config/app_config.local.php config/app_config.local.php.backup.$(date +%Y%m%d)
# Store backup in secure location (password manager, not git)

# 4. Ensure APP_ENV is set to production for live
# In app_config.php: 'env' => 'production'
```

### Phase 2: Rotate Each Credential

#### Database Password
```bash
# 1. Generate secure password (32 chars)
openssl rand -base64 32 | tr -d "=+/" | cut -c1-32

# 2. Update MySQL
mysql -u root -p
ALTER USER 'rs_erp_user'@'localhost' IDENTIFIED BY 'NEW_PASSWORD_HERE';
FLUSH PRIVILEGES;
EXIT;

# 3. Update config/app_config.local.php
# 'pass' => 'NEW_PASSWORD_HERE'
```

#### Paystack Keys
1. Login to Paystack Dashboard → Settings → API Keys & Webhooks
2. Click "Regenerate Secret Key"
3. Copy new secret key
4. Update `config/app_config.local.php`:
```php
'paystack' => [
    'public_key' => 'pk_test_newkey...',
    'secret_key' => 'sk_test_newkey...',
    'webhook_secret' => 'whsec_newkey...',
],
```

#### SMTP/Email
```bash
# For Gmail - Create App Password:
# 1. Google Account → Security → 2-Step Verification → App Passwords
# 2. Generate new app password for "Mail"
# 3. Update config/app_config.local.php:
# 'mail' => [
#     'username' => 'your_email@gmail.com',
#     'password' => 'new_app_password_here',
# ],
```

#### Application Key
```bash
# Generate new key
openssl rand -hex 32
# Update config/app_config.local.php:
# 'app' => ['key' => 'generated_key_here'],
```

#### Session Secret
```bash
# Generate new secret
openssl rand -hex 32
# Update config/app_config.local.php:
# 'session' => ['secret' => 'generated_secret_here'],
```

### Phase 3: Verify & Deploy
```bash
# 1. Test locally
php -r "require 'config/db_connection.php'; echo 'DB OK';"

# 2. Test database migrations
# php config/db_init.php (if needed)

# 3. Test critical flows:
#    - User login/logout
#    - Payment processing (test mode)
#    - Email sending
#    - Session persistence

# 4. Deploy to staging first
# 5. Verify staging works
# 6. Deploy to production
```

### Phase 4: Clean Git History (If config was committed)
```bash
# ⚠️ DANGEROUS - Only if config files were committed to git
# This rewrites history - coordinate with team!

# Option A: BFG Repo-Cleaner (faster)
# java -jar bfg.jar --delete-files config/app_config.local.php
# git push --force

# Option B: git filter-branch (built-in)
# git filter-branch --force --index-filter \
#   'git rm --cached --ignore-unmatch config/app_config.local.php' \
#   --prune-empty --tag-name-filter cat -- --all

# Option C: git filter-repo (recommended)
# git filter-repo --path config/app_config.local.php --invert-paths
# git push --force

# After cleanup, verify:
git log --all --full-history -- config/app_config.local.php
# Should show no results
```

---

## 🔍 Verification Checklist

After rotation, verify:

- [ ] `config/app_config.local.php` not in git: `git ls-files | grep app_config.local.php` (empty)
- [ ] `.gitignore` contains `config/app_config.local.php`
- [ ] Database connection works with new password
- [ ] Paystack test payment succeeds
- [ ] SMTP test email sends successfully
- [ ] Application key works (no encryption errors)
- [ ] Sessions work (login/logout)
- [ ] All environments updated (local, staging, production)
- [ ] Team notified of new credentials (via secure channel)
- [ ] Old credentials revoked/disabled

---

## 🚨 Emergency Contacts

If you suspect credentials were compromised:

1. **Immediately** rotate ALL credentials above
2. Check Paystack dashboard for unauthorized transactions
3. Check database access logs for suspicious activity
4. Check email sending logs for spam/abuse
5. Contact:
   - Paystack Support: support@paystack.com
   - Hosting provider security team
   - Your security team

---

## 📚 Prevention Best Practices

### 1. Never Commit Config with Secrets
```bash
# Add to global gitignore
git config --global core.excludesfile ~/.gitignore_global
echo "config/app_config.local.php" >> ~/.gitignore_global
```

### 2. Use Environment-Specific Config Files
```
config/app_config.php           # Base config (safe to commit, no secrets)
config/app_config.local.php     # Local overrides (gitignored, has secrets)
config/app_config.production.php # Production (deployed via CI/CD, not in git)
```

### 3. Secret Scanning in CI/CD
Add to your pipeline:
```yaml
# GitHub Actions example
- name: Secret Scan
  uses: trufflesecurity/trufflehog@main
  with:
    path: ./
    base: main
    head: HEAD
```

### 4. Pre-commit Hooks
```bash
# Install pre-commit
pip install pre-commit
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets
```

### 5. Regular Rotation Schedule
- **Database passwords**: Every 90 days
- **API keys**: Every 180 days or after team member leaves
- **Encryption keys**: Annually (with migration plan)
- **SMTP passwords**: Every 90 days

---

## 📝 Rotation Log Template

| Date | Credential Rotated | Rotated By | Verified By | Notes |
|------|-------------------|------------|-------------|-------|
| 2025-10-28 | Database Password | [Name] | [Name] | Initial rotation |
| 2025-10-28 | Paystack Keys | [Name] | [Name] | Initial rotation |
| 2025-10-28 | SMTP Password | [Name] | [Name] | Initial rotation |
| 2025-10-28 | App Key | [Name] | [Name] | Initial rotation |
| 2025-10-28 | Session Secret | [Name] | [Name] | Initial rotation |

---

## 🔗 Related Documentation

- [WORK_COMPLETED_SUMMARY.md](WORK_COMPLETED_SUMMARY.md) - Implementation summary
- [IMPLEMENTATION_PROGRESS.md](IMPLEMENTATION_PROGRESS.md) - Progress tracking
- [TODO.md](TODO.md) - Current tasks

---

**Remember**: Security is a process, not a one-time event. Schedule regular rotations and automate where possible!