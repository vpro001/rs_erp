<?php
// includes/header.php
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config/db_connection.php';

$user = current_user();

// Fetch unread notifications for the user
$notifications = [];
$unread_count = 0;
if ($user && isset($conn)) {
    try {
        $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 AND archived = 0 ORDER BY created_at DESC LIMIT 5");
        $stmt->bind_param("s", $user['id']);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $notifications[] = $row;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0 AND archived = 0");
        $stmt->bind_param("s", $user['id']);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $unread_count = intval($row['count']);
        }
        $stmt->close();
    } catch (Exception $e) {
        // Ignore
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . " - Royal Solutions ERP" : "Royal Solutions ERP"; ?></title>

    <!-- Deep Space Neon — Google Fonts: Space Grotesk, Plus Jakarta Sans, JetBrains Mono -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.BASE_URL = "<?php echo BASE_URL; ?>";
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        display: ['Space Grotesk', 'sans-serif'],
                        body: ['Plus Jakarta Sans', 'sans-serif'],
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        // Deep Space Neon Palette
                        app: { bg: '#07080A' },
                        surface: {
                            base: 'rgba(22, 25, 31, 0.6)',
                            elevated: 'rgba(35, 40, 48, 0.8)',
                        },
                        accent: {
                            cyan: '#00F0FF',
                            purple: '#8A2BE2',
                        },
                        status: {
                            success: '#00FF9D',
                            warning: '#FFB800',
                            danger: '#FF2A55',
                        },
                        // Map semantic Tailwind shorthands to neon palette
                        blue: { 600: '#8A2BE2', 500: '#7B24D0', 400: '#9D50F5' },
                        indigo: { 600: '#00F0FF', 500: '#00D8E8', 400: '#33F3FF' },
                        emerald: { 600: '#00FF9D', 500: '#00E88C', 400: '#33FFAD' },
                        amber: { 600: '#FFB800', 500: '#E8A700', 400: '#FFC933' },
                        red: { 500: '#FF2A55', 600: '#E81F44', 400: '#FF5577' },
                    },
                    boxShadow: {
                        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
                        'neon-cyan': '0 0 20px rgba(0, 240, 255, 0.25), 0 0 60px rgba(0, 240, 255, 0.1)',
                        'neon-purple': '0 0 20px rgba(138, 43, 226, 0.35), 0 0 60px rgba(138, 43, 226, 0.15)',
                        'card-hover': '0 16px 48px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,240,255,0.15)',
                    },
                    backgroundImage: {
                        'gradient-neon': 'linear-gradient(135deg, #8A2BE2 0%, #00F0FF 100%)',
                        'gradient-danger': 'linear-gradient(135deg, #FF2A55 0%, #FFB800 100%)',
                        'gradient-success': 'linear-gradient(135deg, #00FF9D 0%, #00F0FF 100%)',
                    },
                    animation: {
                        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'slide-up': 'slideUp 0.35s cubic-bezier(0.4, 0, 0.2, 1) forwards',
                    },
                    keyframes: {
                        slideUp: {
                            '0%': { opacity: '0', transform: 'translateY(12px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' },
                        }
                    }
                }
            }
        }
    </script>

    <!-- Lucide Icons CDN -->
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        /* ============================================================
           ROOT & TYPOGRAPHY CONTRAST SYSTEM
        ============================================================ */
        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', 'Segoe UI', system-ui, sans-serif !important;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .font-display,
        [class*="font-display"] {
            font-family: 'Space Grotesk', sans-serif !important;
            letter-spacing: -0.01em;
        }

        .font-mono,
        code,
        pre,
        [class*="font-mono"] {
            font-family: 'JetBrains Mono', monospace !important;
        }

        /* ============================================================
           LIGHT MODE CONTRAST SYSTEM
        ============================================================ */
        /* Light Mode Default Body */
        body {
            background-color: #F8FAFC !important;
            color: #0F172A !important;
        }

        /* ============================================================
           CUSTOM SCROLLBAR
        ============================================================ */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(148, 163, 184, 0.4);
            border-radius: 8px;
        }

        

        ::-webkit-scrollbar-thumb:hover {
            background: #8A2BE2;
        }

        

        /* ============================================================
           GLASSMORPHISM CARD SYSTEM
        ============================================================ */
        .glass-card {
            background: #FFFFFF !important;
            border: 1px solid #E2E8F0 !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05) !important;
            color: #0F172A !important;
        }

        .glass-card-elevated {
            background: #FFFFFF !important;
            border: 1px solid #CBD5E1 !important;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08) !important;
            color: #0F172A !important;
        }

        

        

        /* Card Hover */
        .card-hoverable {
            transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1),
                box-shadow 0.28s cubic-bezier(0.4, 0, 0.2, 1),
                border-color 0.28s ease;
        }

        .card-hoverable:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.08) !important;
        }

        

        /* ============================================================
           SIDEBAR & TOPBAR CONTRAST
        ============================================================ */
        #sidebar {
            background: #FFFFFF !important;
            border-right: 1px solid #E2E8F0 !important;
            color: #0F172A !important;
        }

        

        .sidebar-active {
            background: linear-gradient(90deg, rgba(138, 43, 226, 0.1) 0%, rgba(0, 240, 255, 0.08) 100%) !important;
            border-left: 3px solid #8A2BE2 !important;
            color: #6D28D9 !important;
            font-weight: 700 !important;
        }

        

        #topbar {
            background: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(20px) !important;
            -webkit-backdrop-filter: blur(20px) !important;
            border-bottom: 1px solid #E2E8F0 !important;
            color: #0F172A !important;
        }

        

        /* ============================================================
           INPUT CONTRAST SYSTEM
        ============================================================ */
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="number"],
        input[type="date"],
        input[type="search"],
        select,
        textarea {
            background: #FFFFFF !important;
            border: 1px solid #CBD5E1 !important;
            color: #0F172A !important;
            transition: all 0.2s ease !important;
        }

        input::placeholder,
        select::placeholder,
        textarea::placeholder {
            color: #94A3B8 !important;
        }

        input:focus,
        select:focus,
        textarea:focus {
            background: #FFFFFF !important;
            border-color: #8A2BE2 !important;
            box-shadow: 0 0 0 3px rgba(138, 43, 226, 0.15) !important;
            outline: none !important;
        }

        

        

        

        /* ============================================================
           TABLE SYSTEM CONTRAST
        ============================================================ */
        table th {
            font-family: 'Space Grotesk', sans-serif !important;
            font-weight: 700 !important;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            font-size: 11px;
            color: #475569 !important;
            border-bottom: 1px solid #E2E8F0 !important;
        }

        

        table tbody tr {
            border-bottom: 1px solid #F1F5F9 !important;
            color: #1E293B !important;
        }

        

        table tbody tr:nth-child(even) {
            background: rgba(241, 245, 249, 0.5) !important;
        }

        

        table tbody tr:hover {
            background: rgba(138, 43, 226, 0.05) !important;
        }

        

        /* ============================================================
           BUTTONS & GLASS UTILITIES
        ============================================================ */
        .btn-neon {
            background: linear-gradient(135deg, #8A2BE2 0%, #00F0FF 100%);
            color: #07080A !important;
            font-weight: 700;
            font-family: 'Space Grotesk', sans-serif;
            letter-spacing: 0.02em;
            border: none;
            transition: all 0.22s ease;
        }

        .btn-neon:hover {
            box-shadow: 0 0 24px rgba(0, 240, 255, 0.4), 0 0 48px rgba(138, 43, 226, 0.3);
            transform: translateY(-1px);
        }

        .btn-glass {
            background: #F1F5F9;
            border: 1px solid #CBD5E1;
            color: #0F172A !important;
            font-weight: 600;
            transition: all 0.22s ease;
        }

        .btn-glass:hover {
            background: #E2E8F0;
            color: #6D28D9 !important;
        }

        

        

        /* ============================================================
           ACCESSIBLE BADGES SYSTEM
        ============================================================ */
        .badge-success {
            background: #DCFCE7 !important;
            color: #15803D !important;
            border: 1px solid #86EFAC !important;
            font-weight: 700 !important;
        }

        

        .badge-warning {
            background: #FEF3C7 !important;
            color: #B45309 !important;
            border: 1px solid #FDE68A !important;
            font-weight: 700 !important;
        }

        

        .badge-danger {
            background: #FEE2E2 !important;
            color: #B91C1C !important;
            border: 1px solid #FCA5A5 !important;
            font-weight: 700 !important;
        }

        

        .badge-info {
            background: #E0F2FE !important;
            color: #0369A1 !important;
            border: 1px solid #7DD3FC !important;
            font-weight: 700 !important;
        }

        

        /* ============================================================
           DROPDOWN PANELS CONTRAST
        ============================================================ */
        .dropdown-panel {
            background: #FFFFFF !important;
            border: 1px solid #CBD5E1 !important;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.12) !important;
            color: #0F172A !important;
        }

        

        /* ============================================================
           PAGE TRANSITIONS
        ============================================================ */
        main {
            animation: slideUpFade 0.35s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

        @keyframes slideUpFade {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        

        

        

        

        

        

        
    </style>
</head>

<body class="bg-slate-50 text-slate-900  font-sans transition-colors duration-300 min-h-screen flex"
    style="background-color: #f1f3f7;">

    <!-- App container layout -->
    <div class="flex w-full min-h-screen overflow-hidden">

        <!-- Sidebar Navigation -->
        <?php include __DIR__ . '/sidebar.php'; ?>

        <!-- Main Content Area -->
        <div class="flex-1 flex flex-col min-w-0 overflow-y-auto">

            <!-- Header Navbar / Sticky Topbar -->
            <header id="topbar" class="h-16 flex items-center justify-between px-6 sticky top-0 z-40">
                <!-- Left Header: Mobile Toggle and Title -->
                <div class="flex items-center space-x-4">
                    <button id="mobile-sidebar-toggle"
                        class="lg:hidden text-slate-500 hover:text-slate-800   transition-colors">
                        <i data-lucide="menu" class="w-6 h-6"></i>
                    </button>
                    <h1 class="text-base font-display font-semibold text-slate-800  tracking-tight">
                        <?php echo isset($page_title) ? $page_title : "Royal Solutions"; ?>
                    </h1>
                </div>

                <!-- Right Header: Actions -->
                <div class="flex items-center space-x-4">

                    <!-- Notifications Dropdown -->
                    <div class="relative">
                        <button id="notifications-toggle"
                            class="p-2 text-slate-500 hover:text-slate-700   bg-white/60  border border-slate-200  rounded-lg transition-all duration-200 hover:border-purple-400 relative">
                            <i data-lucide="bell" class="w-5 h-5"></i>
                            <span id="notifications-badge"
                                class="absolute top-0 right-0 w-2 h-2 bg-[#FF2A55] rounded-full ring-1 ring-white/10 animate-pulse <?php echo $unread_count > 0 ? '' : 'hidden'; ?>"></span>
                        </button>

                        <!-- Notifications Panel -->
                        <div id="notifications-panel"
                            class="dropdown-panel hidden absolute right-0 mt-2 w-80 rounded-xl z-50 overflow-hidden">
                            <div class="px-4 py-3 border-b border-slate-100 flex justify-between items-center">
                                <span
                                    class="font-display font-semibold text-sm text-slate-800  tracking-wide">Notifications</span>
                                <?php if ($unread_count > 0): ?>
                                    <button id="mark-all-read"
                                        class="text-[10px] text-cyan-600 hover:underline font-semibold tracking-wide uppercase">Mark
                                        all read</button>
                                <?php endif; ?>
                            </div>
                            <div id="notifications-list" class="max-h-72 overflow-y-auto divide-y divide-slate-100">
                                <?php if (empty($notifications)): ?>
                                    <div class="px-4 py-8 text-center text-sm text-slate-400 ">
                                        <i data-lucide="bell-off" class="w-8 h-8 mx-auto mb-2 opacity-55"></i>
                                        No new notifications
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($notifications as $notif): ?>
                                        <a href="<?php echo $notif['link'] ? sanitize($notif['link']) : '#'; ?>"
                                            class="block px-4 py-3 hover:bg-purple-50 transition-colors">
                                            <div class="flex justify-between items-start">
                                                <span
                                                    class="font-semibold text-xs text-slate-800 "><?php echo sanitize($notif['title']); ?></span>
                                                <span
                                                    class="text-[10px] text-slate-400"><?php echo date('M d, H:i', strtotime($notif['created_at'])); ?></span>
                                            </div>
                                            <p class="text-xs text-slate-500  mt-0.5 line-clamp-2">
                                                <?php echo sanitize($notif['message']); ?></p>
                                        </a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="px-4 py-2.5 border-t border-slate-100 text-center">
                                <a href="#"
                                    class="text-[10px] font-semibold text-cyan-600 hover:underline uppercase tracking-wider">View
                                    All Notifications</a>
                            </div>
                        </div>
                    </div>

                    <!-- Profile Dropdown -->
                    <?php if ($user): ?>
                        <div class="relative">
                            <button id="profile-toggle" class="flex items-center space-x-2 focus:outline-none">
                                <img src="<?php echo $user['avatar'] ? sanitize($user['avatar']) : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop'; ?>"
                                    alt="User Avatar"
                                    class="w-9 h-9 rounded-full object-cover border border-slate-200 hover:border-purple-400 hover:scale-105 transition-all duration-200 shadow-lg">
                                <div class="hidden md:block text-left">
                                    <p class="text-xs font-semibold text-slate-900  leading-tight">
                                        <?php echo sanitize($user['first_name'] . ' ' . $user['last_name']); ?></p>
                                    <span
                                        class="text-[10px] font-medium text-slate-400 uppercase tracking-wider"><?php echo sanitize($user['role']); ?></span>
                                </div>
                                <i data-lucide="chevron-down" class="w-4 h-4 text-slate-400"></i>
                            </button>

                            <!-- Profile Menu Panel -->
                            <div id="profile-panel"
                                class="dropdown-panel hidden absolute right-0 mt-2 w-52 rounded-xl z-50 py-1">
                                <div class="px-4 py-2.5 border-b border-slate-100 md:hidden">
                                    <p class="text-sm font-semibold text-slate-955 ">
                                        <?php echo sanitize($user['first_name'] . ' ' . $user['last_name']); ?></p>
                                    <span
                                        class="text-xs text-slate-400 uppercase tracking-wider font-semibold"><?php echo sanitize($user['role']); ?></span>
                                </div>

                                <a href="<?php echo BASE_URL; ?>/profile.php"
                                    class="flex items-center space-x-2 px-4 py-2.5 text-sm text-slate-600  hover:bg-purple-50 hover:text-purple-600 transition-colors duration-150">
                                    <i data-lucide="user" class="w-4 h-4"></i>
                                    <span>My Profile</span>
                                </a>
                                <a href="<?php echo BASE_URL; ?>/settings.php"
                                    class="flex items-center space-x-2 px-4 py-2.5 text-sm text-slate-600  hover:bg-purple-50 hover:text-purple-600 transition-colors duration-150">
                                    <i data-lucide="settings" class="w-4 h-4"></i>
                                    <span>Account Settings</span>
                                </a>

                                <hr class="border-slate-100 my-1">

                                <a href="<?php echo BASE_URL; ?>/logout.php"
                                    class="flex items-center space-x-2 px-4 py-2.5 text-sm hover:bg-[#FF2A55]/8 transition-colors duration-150">
                                    <i data-lucide="log-out" class="w-4 h-4 text-red-500"></i>
                                    <span class="text-[#FF2A55] font-semibold">Sign Out</span>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </header>

            <!-- Flash Messages Display -->
            <?php $flash = get_flash_message(); ?>
            <?php if ($flash): ?>
                <div class="px-6 pt-4">
                    <div class="flex items-center justify-between p-3.5 rounded-xl border <?php
                    switch ($flash['type']) {
                        case 'success':
                            echo 'badge-success';
                            $icon = 'circle-check';
                            break;
                        case 'error':
                            echo 'badge-danger';
                            $icon = 'alert-circle';
                            break;
                        case 'warning':
                            echo 'badge-warning';
                            $icon = 'alert-triangle';
                            break;
                        default:
                            echo 'badge-info';
                            $icon = 'info';
                    }
                    ?>">
                        <div class="flex items-center space-x-3">
                            <i data-lucide="<?php echo $icon; ?>" class="w-5 h-5 flex-shrink-0"></i>
                            <span class="text-sm font-medium"><?php echo $flash['message']; ?></span>
                        </div>
                        <button class="text-slate-400 hover:text-slate-600  transition-colors"
                            onclick="this.parentElement.remove()">
                            <i data-lucide="x" class="w-4 h-4"></i>
                        </button>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Page Main Workspace -->
            <main class="flex-1 p-6">